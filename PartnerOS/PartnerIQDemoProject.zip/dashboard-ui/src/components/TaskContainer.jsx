import { Container, Card, Col, Form, Row, Button } from "react-bootstrap";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { io } from "socket.io-client";

const socket = io("http://localhost:5000");

const TaskContainer = (props) => {
    const [logs, setLogs] = useState([]);
    const [progress, setProgress] = useState(0);
    const [message, setMessage] = useState("0% completed");

    useEffect(() => {
            socket.on("log" + props.suffix, (data) => {
                props.printLog(data.log);
            });
    
            socket.on("progress" + props.suffix, (data) => {
                setProgress(data.progress);
                setMessage(data.message);
            });
    
            return () => {
                socket.off("log" + props.suffix);
                socket.off("progress" + props.suffix);
            };
        }, []);

    const runTask = () => {
        axios.post(props.taskUrl);
        props.printLog("---------------------");
        props.printLog("[" + props.title + "]");
        setProgress(0);
        setMessage("0% completed");
    };

    return (
        <div>
            <Container>
                <Row>
                    <Col sm={12}>
                        <Card style={{ width: '100%', marginBottom: '10px' }}>
                            <Card.Body>
                                <Form>
                                    <Row>
                                        <Col sm={8}><Form.Label style={{ paddingTop: '7px', fontSize: "16px", display: 'flex', justifyContent: "start", textDecoration: "underline" }}>{props.title}</Form.Label>
                                        </Col>
                                        <Col sm={4} className="text-start">
                                            <Form.Label style={{ paddingTop: '11px', fontSize: "14px", display: 'flex', justifyContent: "start" }}>{message}</Form.Label>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col sm={3} className="text-start">
                                            <Button size="sm" onClick={runTask} style={{ fontSize: '14px', paddingTop: '7px' }} disabled={props.isDisabled}>Run task</Button>
                                        </Col>
                                        <Col sm={9}>
                                            <div style={{ paddingTop: '10px' }}>
                                                <progress value={progress} max="100" style={{ width: "100%" }} />
                                                <p style={{ textAlign: 'left' }}>{props.task}</p>
                                            </div>
                                        </Col>

                                    </Row>
                                </Form>
                            </Card.Body></Card>
                    </Col>
                </Row>
            </Container>
        </div>
    );
}

export default TaskContainer;
