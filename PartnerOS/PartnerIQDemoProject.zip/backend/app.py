from flask import Flask, request, jsonify
from flask_socketio import SocketIO
from flask_cors import CORS
import subprocess
import threading
import time
import requests
import zipfile
import io
import os
import shutil
import openai
import re

app = Flask(__name__)

CORS(app)

socketio = SocketIO(app, cors_allowed_origins="*")

@app.route("/start-script", methods=["POST"])
def start_script():
    def run_task():
        total = 10
        for i in range(total + 1):
            percent = int(i * 100 / total)
            log = f"[step {i}] Doing some work..."
            socketio.emit("progress", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log", {"log": log})
            time.sleep(1)

        socketio.emit("log", {"log": "[done] Task completed"})
        socketio.emit("progress", {"progress": 100, "message": "Task complete"})

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/create-backend-app", methods=["POST"])
def create_backend_app():
    def run_task():
        # ===== Settings =====
        project_name = "PartnerIQDemoBackendServer"
        extract_to = "."
        spring_initializr_url = "https://start.spring.io/starter.zip"

        params = {
            "type": "gradle-project",
            "language": "java",
            "bootVersion": "3.5.0",                 # Spring Boot version
            "baseDir": project_name,                # ZIP Path
            "groupId": "com.example",
            "artifactId": project_name,
            "name": project_name,
            "packageName": "com.wu.partneriq",
            "dependencies": "web,data-jpa,security,data-mongodb,mysql"
        }

        total = 10
        # ===== Request Spring Initializr API =====
        percent = int(3 * 100 / 10)
        log = f"Requesting Spring Boot project from Spring Initializr..."
        socketio.emit("progress_create_backend", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_create_backend", {"log": log})
        time.sleep(1)

        response = requests.get(spring_initializr_url, params=params)
        if response.status_code == 200:
            percent = int(6 * 100 / 10)
            log = f"Project package created. Download successful. Extracting..."
            socketio.emit("progress_create_backend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_backend", {"log": log})
            time.sleep(1)

            # UNZIP to the project path
            with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
                zip_ref.extractall(extract_to)
            percent = int(10 * 100 / 10)
            log = f"Project extracted to: {os.path.abspath(extract_to)}"
            socketio.emit("progress_create_backend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_backend", {"log": log})
        else:
            percent = int(10 * 100 / 10)
            log = f"Failed to download project. Status code: {response.status_code}"
            socketio.emit("progress_create_backend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_backend", {"log": log})

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/create-frontend-app", methods=["POST"])
def create_frontend_app():
    def run_task():
        # ===== Settings =====
        project_name = "partneriq-demo-ui-frontend"
        target_dir = "./"
        project_path = os.path.join(target_dir, project_name)
        dependencies = [
            "@testing-library/jest-dom@^5.17.0",
            "@testing-library/react@^13.4.0",
            "@testing-library/user-event@^13.5.0",
            "axios@^1.7.7",
            "bootstrap@^5.3.3",
            "prop-types@^15.8.1",
            "react@^18.3.1",
            "react-bootstrap@^2.10.5",
            "react-datepicker@^7.6.0",
            "react-dom@^18.3.1",
            "react-router-dom@^6.27.0",
            "react-scripts@5.0.1",
            "react-transition-group@^4.4.5",
            "web-vitals@^2.1.4",
            "wumodclient-ui@^0.1.49"
        ]

        # Step 1: create React project
        try:
            percent = int(0 * 100 / 10)
            log = f"Creating a new UI project..."
            socketio.emit("progress_create_frontend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_frontend", {"log": log})
            time.sleep(1)

            percent = int(1 * 100 / 10)
            log = f"Installing packages. This might take a couple of minutes."
            socketio.emit("progress_create_frontend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_frontend", {"log": log})

            process = subprocess.Popen(
                ["npx.cmd", "create-react-app", project_name],
                cwd=target_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                text=True,
                bufsize=1
            )
            for line in process.stdout:
                socketio.emit("progress_create_frontend", {"progress": percent, "message": f"{percent}% completed"})
                socketio.emit('log_create_frontend', {'message': line})
                print('log', {'message': line})

            time.sleep(1)

            percent = int(3 * 100 / 10)
            log = f"Installing react, react-dom, and react-scripts with cra-template..."
            socketio.emit("progress_create_frontend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_frontend", {"log": log})
            time.sleep(2)

            percent = int(5 * 100 / 10)
            log = f"Success! Created partneriq-demo-ui-frontend at {project_path}"
            socketio.emit("progress_create_frontend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_frontend", {"log": log})
            time.sleep(1)

            #exit_code = process.wait()

        except subprocess.CalledProcessError as e:
            percent = int(10 * 100 / 10)
            log = f"Failed to create React app: {e}"
            socketio.emit("progress_create_frontend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_frontend", {"log": log})
            exit(1)

        # Step 2: install dependencies
        try:
            percent = int(7 * 100 / 10)
            log = f"Installing template dependencies using npm..."
            socketio.emit("progress_create_frontend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_frontend", {"log": log})
            time.sleep(2)

            
            process = subprocess.Popen(
                ["npm.cmd", "install"] + dependencies,
                cwd=project_path,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                text=True,
                bufsize=1
            )
            for line in process.stdout:
                socketio.emit("progress_create_frontend", {"progress": percent, "message": f"{percent}% completed"})
                socketio.emit('log_create_frontend', {'message': line})
                print('log', {'message': line})

            #exit_code = process.wait()

            percent = int(9 * 100 / 10)
            log = f"added 1323 packages."
            socketio.emit("progress_create_frontend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_frontend", {"log": log})
            time.sleep(2)

            percent = int(10 * 100 / 10)
            log = f"Dependencies {dependencies} installed."
            socketio.emit("progress_create_frontend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_frontend", {"log": log})
        except subprocess.CalledProcessError as e:
            percent = int(10 * 100 / 10)
            log = f"Failed to install dependencies: {e}"
            socketio.emit("progress_create_frontend", {"progress": percent, "message": f"{percent}% completed"})
            socketio.emit("log_create_frontend", {"log": log})
            exit(1)


    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/create-frontend-ui", methods=["POST"])
def create_frontend_UI():
    def run(command, cwd=None):
        print(f"\n Running: {command}")
        subprocess.run(command, shell=True, check=True, cwd=cwd)
    
    def run_task():
        percent = int(0 * 100 / 10)
        log = f"Generating PartnerIQ Demo UI..."
        socketio.emit("progress_create_ui", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_create_ui", {"log": log})
        time.sleep(1)

        percent = int(1 * 100 / 10)
        log = f"Open prompt file : ui_prompt.txt"
        socketio.emit("progress_create_ui", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_create_ui", {"log": log})
        time.sleep(1)

        # call llm service to generate UI code
        client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        with open("ui_prompt.txt", "r", encoding="utf-8") as file:
            prompt_text = file.read()

        percent = int(2 * 100 / 10)
        log = f"Requesting LLM service to generate UI code. This might take a couple of minutes..."
        socketio.emit("progress_create_ui", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_create_ui", {"log": log})

        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": prompt_text},
                {"role": "user", "content": "please start code generation"}
            ],
            temperature=0.0,
        )

        percent = int(6 * 100 / 10)
        log = f"Got response from LLM service."
        socketio.emit("progress_create_ui", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_create_ui", {"log": log})
        time.sleep(1)

        reply = response.choices[0].message.content
        match = re.search(r"```jsx\n([\s\S]*?)```", reply)

        if match:
            jsx_code = match.group(1).strip()

        with open("ui_template_src/AnimatedRoutes.jsx", "w", encoding="utf-8") as f:
            f.write(jsx_code)

        percent = int(8 * 100 / 10)
        log = f"Saved GPT response in file AnimatedRoutes.jsx"
        socketio.emit("progress_create_ui", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_create_ui", {"log": log})
        time.sleep(1)

        print("Saved GPT response in file AnimatedRoutes.jsx")

        # Copy template files
        source_dir = os.path.abspath("ui_template_src")
        target_dir = os.path.abspath("partneriq-demo-ui-frontend/src")
        shutil.copytree(source_dir, target_dir, dirs_exist_ok=True)
        #print(f"Copied all files from {source_dir} to {target_dir}")
        #source_dir = os.path.abspath("ui_template_src/AnimatedRoutes.jsx")
        #target_dir = os.path.abspath("partneriq-demo-ui-frontend/src/AnimatedRoutes.jsx")
        #shutil.copyfile(source_dir, target_dir)

        percent = int(10 * 100 / 10)
        log = f"Copied AnimatedRoutes.jsx file from {source_dir} to {target_dir}"
        socketio.emit("progress_create_ui", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_create_ui", {"log": log})

        print(f"Copied AnimatedRoutes.jsx file from {source_dir} to {target_dir}")

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/build-deploy", methods=["POST"])
def build_deploy():
    def run(command, cwd=None):
        print(f"\n Running: {command}")
        subprocess.run(command, shell=True, check=True, cwd=cwd)
    
    def run_task():
        percent = int(1 * 100 / 10)
        log = f"Building PartnerIQ Demo application..."
        socketio.emit("progress_build_deploy", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_build_deploy", {"log": log})
        time.sleep(2)

        percent = int(3 * 100 / 10)
        log = f"PartnerIQ Demo application was built successfully."
        socketio.emit("progress_build_deploy", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_build_deploy", {"log": log})
        time.sleep(2)

        percent = int(5 * 100 / 10)
        log = f"Deploying PartnerIQ Demo application..."
        socketio.emit("progress_build_deploy", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_build_deploy", {"log": log})
        time.sleep(2)

        percent = int(7 * 100 / 10)
        log = f"PartnerIQ Demo application was deployed successfully."
        socketio.emit("progress_build_deploy", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_build_deploy", {"log": log})
        time.sleep(2)

        percent = int(10 * 100 / 10)
        log = f"Starting up PartnerIQ Demo application..."
        socketio.emit("progress_build_deploy", {"progress": percent, "message": f"{percent}% completed"})
        socketio.emit("log_build_deploy", {"log": log})

        project_path = os.path.abspath("partneriq-demo-ui-frontend")
        subprocess.run(["npm", "start"], cwd=project_path, check=True, shell=True)

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000)