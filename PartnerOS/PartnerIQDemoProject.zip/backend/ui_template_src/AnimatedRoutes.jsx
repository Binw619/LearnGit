import React from 'react';
import { useLocation, useNavigate, Routes, Route } from 'react-router-dom';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import { withRouter } from "./utils/withRouter";
import { Container, Row, Col, Button } from "react-bootstrap";
import { LoginModule, SignupModule, KYCTemplateModule, AddressModule, NameModule, NameType, PaymentModule, TxnReceiptModule, TxnReviewModule } from "wumodclient-ui";
import './App.css';

export const LoginModuleContainer = withRouter(() => {
    const navigate = useNavigate();
    return (
        <div className="vh-100 d-flex flex-column justify-content-center align-items-center position-relative">
            <Container style={{ width: '1100px' }}>
                <Row>
                    <Col><LoginModule /></Col>
                </Row>
            </Container>
        </div>
    );
});

export const SignupModuleContainer = withRouter(() => {
    const navigate = useNavigate();
    return (
        <div className="vh-100 d-flex flex-column justify-content-center align-items-center position-relative">
            <Container style={{ width: '1100px' }}>
                <Row>
                    <Col><SignupModule /></Col>
                </Row>
            </Container>
        </div>
    );
});

export const SenderNameModuleContainer = withRouter(() => {
    const navigate = useNavigate();
    return (
        <div className="vh-100 d-flex flex-column justify-content-center align-items-center position-relative">
            <Container style={{ width: '1100px' }}>
                <Row>
                    <Col><NameModule title="Sender" type={NameType.TypeD} /></Col>
                </Row>
            </Container>
            <div className="mt-3 d-flex justify-content-end">
                <Button onClick={() => navigate("/senderdetails")}>Continue</Button>
            </div>
        </div>
    );
});

export const RecepientNameModuleContainer = withRouter(() => {
    const navigate = useNavigate();
    return (
        <div className="vh-100 d-flex flex-column justify-content-center align-items-center position-relative">
            <Container style={{ width: '1100px' }}>
                <Row>
                    <Col><NameModule title="Recepient" type={NameType.TypeD} /></Col>
                </Row>
            </Container>
            <div className="mt-3 d-flex justify-content-end">
                <Button onClick={() => navigate("/txnreview")}>Continue</Button>
            </div>
        </div>
    );
});

export const SenderDetailsContainer = withRouter(() => {
    const navigate = useNavigate();
    return (
        <div className="vh-100 d-flex flex-column justify-content-center align-items-center position-relative">
            <Container style={{ width: '1100px' }}>
                <Row>
                    <Col><AddressModule /></Col>
                </Row>
                <Row>
                    <Col><KYCTemplateModule countryCode="PH" /></Col>
                </Row>
            </Container>
            <div className="mt-3 d-flex justify-content-end">
                <Button onClick={() => navigate("/recepientnamemodule")}>Continue</Button>
            </div>
        </div>
    );
});

export const PaymentModuleContainer = withRouter(() => {
    const navigate = useNavigate();
    return (
        <div className="vh-100 d-flex flex-column justify-content-center align-items-center position-relative">
            <Container style={{ width: '1100px' }}>
                <Row>
                    <Col><PaymentModule countrycode="PH" currencycode="PHP" /></Col>
                </Row>
            </Container>
            <div className="mt-3 d-flex justify-content-end">
                <Button onClick={() => navigate("/signup")}>Register</Button>
                <Button onClick={() => navigate("/mylogin")}>Login</Button>
                <Button onClick={() => navigate("/sendernamemodule")}>Continue</Button>
            </div>
        </div>
    );
});

export const TxnReviewModuleContainer = withRouter(() => {
    const navigate = useNavigate();
    return (
        <div className="vh-100 d-flex flex-column justify-content-center align-items-center position-relative">
            <Container style={{ width: '1100px' }}>
                <Row>
                    <Col><TxnReviewModule /></Col>
                </Row>
            </Container>
            <div className="mt-3 d-flex justify-content-end">
                <Button onClick={() => navigate("/txnreceipt")}>Confirm</Button>
            </div>
        </div>
    );
});

export const TxnReceiptModuleContainer = withRouter(() => {
    const navigate = useNavigate();
    return (
        <div className="vh-100 d-flex flex-column justify-content-center align-items-center position-relative">
            <Container style={{ width: '1100px' }}>
                <Row>
                    <Col><TxnReceiptModule /></Col>
                </Row>
            </Container>
            <div className="mt-3 d-flex justify-content-end">
                <Button onClick={() => navigate("/")}>Complete</Button>
            </div>
        </div>
    );
});

const AnimatedRoutes = () => {
    const location = useLocation();
    return (
        <TransitionGroup className="page-wrapper">
            <CSSTransition key={location.pathname} classNames="page" timeout={300}>
                <Routes location={location}>
                    <Route path="/" element={<PaymentModuleContainer />} />
                    <Route path="/sendernamemodule" element={<SenderNameModuleContainer />} />
                    <Route path="/recepientnamemodule" element={<RecepientNameModuleContainer />} />
                    <Route path="/senderdetails" element={<SenderDetailsContainer />} />
                    <Route path="/mylogin" element={<LoginModuleContainer />} />
                    <Route path="/signup" element={<SignupModuleContainer />} />
                    <Route path="/txnreview" element={<TxnReviewModuleContainer />} />
                    <Route path="/txnreceipt" element={<TxnReceiptModuleContainer />} />
                </Routes>
            </CSSTransition>
        </TransitionGroup>
    );
};

export default AnimatedRoutes;