import requests
import zipfile
import io
import os

# ===== Settings =====
project_name = "PartnerIQDemoBackendServer"
extract_to = "./PartnerIQDemoBackendServer"

spring_initializr_url = "https://start.spring.io/starter.zip"

params = {
    "type": "gradle-project",
    "language": "java",
    "bootVersion": "3.5.0",                 # Spring Boot version
    "baseDir": project_name,                # ZIP Path
    "groupId": "com.example",
    "artifactId": project_name,
    "name": project_name,
    "packageName": "com.wu.partneriq",
    "dependencies": "web,data-jpa,security,data-mongodb,mysql"
}

# ===== Request Spring Initializr API =====
print("Requesting Spring Boot project from Spring Initializr...")
response = requests.get(spring_initializr_url, params=params)

if response.status_code == 200:
    print("Download successful. Extracting ZIP...")

    # UNZIP to the project path
    with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
        zip_ref.extractall(extract_to)

    print(f"Project extracted to: {os.path.abspath(extract_to)}")
else:
    print(f"Failed to download project. Status code: {response.status_code}")