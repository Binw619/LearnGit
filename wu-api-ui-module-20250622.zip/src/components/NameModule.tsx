import React from 'react';
import { withRouter } from "../utils/withRouter";
import { Card, Col, FloatingLabel, Form, Row } from "react-bootstrap";

export enum NameType {
    TypeD = 'D',  // 0
    TypeM = 'M'  // 1
}

export type NameProps = {
    title: string;
    type: NameType;
}

const NameModule: React.FC<NameProps> = ({ title, type }) => {
    return (
        <div>
            <Card style={{ width: '100%', marginTop: '10px' }}>
                <Card.Body>
                    <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                        {title}
                    </Card.Title>
                    {
                        type === NameType.TypeD ? (
                            <Form>
                                <Row>
                                    <Col>
                                        <FloatingLabel
                                            controlId="firstName"
                                            label="First Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="middleName"
                                            label="Middle Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="lastName"
                                            label="Last Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                </Row>
                            </Form>
                        ) : (
                            <Form>
                                <Row>
                                    <Col>
                                        <FloatingLabel
                                            controlId="givenName"
                                            label="Given Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="paternalName"
                                            label="Paternal Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="maternalName"
                                            label="Maternal Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                </Row>
                            </Form>
                        )
                    }
                </Card.Body>
            </Card>
        </div>
    );
}

export default withRouter(NameModule);
