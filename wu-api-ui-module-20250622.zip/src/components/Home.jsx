import React, {Component} from 'react';
import {Col, Container, Row} from "react-bootstrap";

class Home extends Component {

    render() {
        return (
            <Container>
                <Row>
                    <Col></Col>
                    <Col></Col>
                </Row>
            </Container>
        );
    }
}

export default Home;