import './App.css';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { useState, useEffect } from 'react';
import DynamicTemplate from "./components/DynamicTemplate";
import React from "react";
import TemplateService from "./services/TemplateService";

function WUApiUI() {
  const [ccList, setCcList] = useState(new Array());

  useEffect(() => {
    TemplateService.getCountryCurrencyList().then(resp => {
      setCcList(resp.data.obj);
    });
  }, []);

  /*return (
    <div className="App">
      <Router>
        <div className="container">
          <Routes>
            <Route path="/" element={<DynamicTemplate ccList={ccList} />} />
          </Routes>
        </div>
      </Router>
    </div>
  );*/

  return (
    <DynamicTemplate ccList={ccList} />
  );
}

export default WUApiUI;
