const CopyWebpackPlugin = require('copy-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const path = require('path');

module.exports = function () {
    return {
        mode: "production",
        entry: path.resolve(__dirname, 'src/index.js'),
        output: {
            path: path.resolve(__dirname, 'dist'),
            filename: `index.js`,
            //意思是把我们的输出作为组件，没有这个在react项目中识别不到export导出的组件
            library: {
                name: 'lg-select-modal',
                type: 'umd', // 以库的形式导出入口文件时，输出的类型,这里是通过umd的方式来暴露library,适用于使用方import的方式导入npm包
                umdNamedDefine: true
            }
        },
        module: {
            rules: [
                {
                    test: /\.(css|scss)$/i,
                    use: ["style-loader", MiniCssExtractPlugin.loader, "css-loader", "sass-loader"],
                },
                {
                    test: /\.(js|jsx)$/,
                    loader: 'babel-loader',
                    exclude: /(node_modules|dist|build|example)/
                },
                {
                    test: /\.png$/,
                    type: 'asset/resource'
                }
            ],
        },
        plugins: [
            new MiniCssExtractPlugin({
                filename: `index.css`, //打包模块的css文件放置到这里
            })
            //new CopyWebpackPlugin(['public']),
            //new CleanWebpackPlugin()
        ],
        //打包时不将以下依赖打包进index.js，需要引用组件的项目提前npm好
        externals: {
            'react': 'react',
            'react-dom': 'react-dom'
        },
        resolve: {
            extensions: ['.js', '.jsx'],
        }
    }
}