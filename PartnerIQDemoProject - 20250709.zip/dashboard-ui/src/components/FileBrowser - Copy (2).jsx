import React, { useEffect, useState } from 'react';
import { Container, Card, Row, Col, Button } from 'react-bootstrap';
import { FolderFill, ArrowLeftCircle } from 'react-bootstrap-icons';
import axios from 'axios';

const FileBrowser = () => {
    const [currentPath, setCurrentPath] = useState('');
    const [directories, setDirectories] = useState([]);

    useEffect(() => {
        fetchDirectory(currentPath);
    }, [currentPath]);

    const fetchDirectory = async (path) => {
        try {
            const response = await axios.get(`http://localhost:5000/list-dir`, {
                params: { path },
            });
            setDirectories(response.data.directories || []);
        } catch (err) {
            console.error('Failed to fetch directories:', err);
        }
    };

    const goUp = () => {
        const parts = currentPath.split('/').filter(Boolean);
        parts.pop();
        const newPath = parts.join('/');
        setCurrentPath(newPath);
    };

    const handleClick = (dir) => {
        const newPath = currentPath ? `${currentPath}/${dir}` : dir;
        setCurrentPath(newPath);
    };

    return (

        <Container>
            <Card style={{ width: '100%', marginTop: '10px' }}>
                <Card.Body>
                    <Card.Title style={{ fontSize: "16px", color: 'black', display: 'flex', justifyContent: "start" }}>
                        Browsing: /{currentPath}
                    </Card.Title>
                    <Row style={{ margin: "10px" }}>
                        <Col cm={12} style={{ display: 'flex', justifyContent: "end" }}>
                            {currentPath && (
                                <Button variant="outline-secondary" size="sm" onClick={goUp}>
                                    <ArrowLeftCircle size={20} /> Up
                                </Button>
                            )}
                        </Col>
                    </Row>
                    <Row xs={2} sm={3} md={4} lg={6}>
                        {directories.map((dir) => (
                            <Col key={dir} className="text-center mb-4">
                                <div
                                    role="button"
                                    onClick={() => handleClick(dir)}
                                    style={{ cursor: 'pointer' }}
                                >
                                    <FolderFill size={48} color="#ffc107" />
                                    <div className="mt-2 text-truncate">{dir}</div>
                                </div>
                            </Col>
                        ))}
                    </Row>
                </Card.Body>
            </Card>
        </Container>
    );
};

export default FileBrowser;