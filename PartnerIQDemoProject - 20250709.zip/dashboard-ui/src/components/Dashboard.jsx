import React, { useEffect, useState, useRef } from "react";
import TaskContainer from './TaskContainer';
import { withRouter } from "../utils/withRouter";
import { Button, Row, Col } from "react-bootstrap";
import FileBrowser from "./FileBrowser";


const Dashboard = () => {
    const [logs, setLogs] = useState([]);
    const logEndRef = useRef(null);

    useEffect(() => {
        if (logEndRef.current) {
            logEndRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [logs]);

    const printLog = (log) => {
        setLogs((prev) => [...prev, log]);
    };

    return (
        <div style={{ fontFamily: "URWGeometricRegular" }}>
            <Row>
                <Col sm={4}>
                    <div style={{ height: '700px', overflowY: 'auto' }}>
                        <TaskContainer title="1 - Create backend application"
                            taskUrl="http://localhost:5000/create-backend-app"
                            suffix="_create_backend"
                            printLog={printLog}
                            isDisabled={false} />
                        <TaskContainer title="2 - Create frontend application"
                            taskUrl="http://localhost:5000/create-frontend-app"
                            suffix="_create_frontend"
                            printLog={printLog}
                            isDisabled={false} />
                        <TaskContainer title="3 - Download PartnerOS api docs"
                            taskUrl="http://localhost:5000/partneros-apidocs"
                            suffix="_partneros_apidoc"
                            printLog={printLog}
                            isDisabled={false} />
                        <TaskContainer title="4 - Generate PartnerOS sdk"
                            taskUrl="http://localhost:5000/partneros-sdk"
                            suffix="_partneros_sdk"
                            printLog={printLog}
                            isDisabled={false} />
                        <TaskContainer title="5 - Build and run backend app"
                            taskUrl="http://localhost:5000/run-backend"
                            suffix="_run_backend"
                            printLog={printLog}
                            isDisabled={false} />
                        <TaskContainer title="6 - Download backend api docs"
                            taskUrl="http://localhost:5000/backend-apidocs"
                            suffix="_backend_apidoc"
                            printLog={printLog}
                            isDisabled={false} />
                        <TaskContainer title="7 - Generate backend sdk"
                            taskUrl="http://localhost:5000/backend-sdk"
                            suffix="_backend_sdk"
                            printLog={printLog}
                            isDisabled={false} />
                        <TaskContainer title="8 - Generate frontend UI"
                            taskUrl="http://localhost:5000/create-frontend-ui"
                            suffix="_create_ui"
                            printLog={printLog}
                            isDisabled={false} />
                        <TaskContainer title="9 - Build and run frontend UI"
                            taskUrl="http://localhost:5000/build-deploy"
                            suffix="_build_deploy"
                            printLog={printLog}
                            isDisabled={false} />
                    </div>
                </Col>
                <Col sm={8}>
                    <div style={{
                        height: "400px",
                        overflowY: "auto",
                        background: "#111",
                        color: "#0f0",
                        padding: "1em",
                        borderRadius: "8px"
                    }}>
                        {logs.map((log, idx) => (
                            <div key={idx} className="text-start">{log}</div>
                        ))}
                        <div ref={logEndRef} />
                    </div>
                    <div>
                        <FileBrowser />
                    </div>
                </Col>
            </Row>
        </div>
    );
};

export default withRouter(Dashboard);
