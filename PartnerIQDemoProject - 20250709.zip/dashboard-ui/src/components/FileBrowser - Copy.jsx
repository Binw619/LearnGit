import React, { useState, useEffect } from 'react';
import { Card, Col, FloatingLabel, Form, Row, InputGroup, DropdownButton, Dropdown, Button } from "react-bootstrap";
import axios from 'axios';

const FileBrowser = () => {
    const [path, setPath] = useState('.');
    const [directories, setDirectories] = useState([]);
    const [history, setHistory] = useState([]);

    useEffect(() => {
        fetchDirectories(path);
    }, [path]);

    const fetchDirectories = async (currentPath) => {
        try {
            const response = await axios.get(`http://localhost:5000/list-dir?path=${encodeURIComponent(currentPath)}`);
            setDirectories(response.data.directories);
        } catch (error) {
            console.error('Error fetching directories:', error);
        }
    };

    const enterDirectory = (folderName) => {
        setHistory([...history, path]);
        setPath(path.endsWith('/') ? path + folderName : path + '/' + folderName);
    };

    const goBack = () => {
        if (history.length === 0) return;
        const newHistory = [...history];
        const previousPath = newHistory.pop();
        setHistory(newHistory);
        setPath(previousPath);
    };

    return (
        <div style={{ padding: '20px' }}>
            <Card style={{ width: '100%', marginTop: '10px' }}>
                <Card.Body>
                    <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                        current path: {path}
                    </Card.Title>
                    <button style={{ display: 'flex', justifyContent: "start" }} className="btn btn-secondary btn-sm mb-3" onClick={goBack} disabled={history.length === 0}>⬅ Go Back</button>
                    <ul className="list-group">
                        {directories.map((dir, idx) => (
                            <li key={idx} className="list-group-item list-group-item-action" onClick={() => enterDirectory(dir)} style={{ cursor: 'pointer' }}>
                                📁 {dir}
                            </li>
                        ))}
                    </ul>
                </Card.Body>
            </Card>
        </div>
    );
};

export default FileBrowser;
