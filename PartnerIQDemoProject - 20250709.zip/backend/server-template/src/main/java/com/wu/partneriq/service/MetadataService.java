package com.wu.partneriq.service;

import com.wu.partneriq.util.FileUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;

@Service
public class MetadataService {
    public ResponseEntity<String> getCclist() {
        try {
            File file = ResourceUtils.getFile("payload/json/country-currency-list.json");
            String jsonStr = FileUtils.readFileToOneLineString(file);
            return ResponseEntity.ok()
                    .header("Content-Type", "application/json")
                    .body(jsonStr);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.notFound().build();
        }
    }
}
