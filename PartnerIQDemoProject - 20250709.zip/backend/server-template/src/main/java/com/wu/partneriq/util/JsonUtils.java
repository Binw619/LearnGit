package com.wu.partneriq.util;


import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import java.io.FileNotFoundException;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

@Component
public class JsonUtils {
    //@Value("${payload.xml}")
    private static String xmlPayloadPath = "payload/xml";
    //@Value("${payload.json}")
    private static String jsonPayloadPath = "payload/json";

    public static String convertXmlToJson(String xmlStr) {
        JSONObject jsonObject = XML.toJSONObject(xmlStr);
        return jsonObject.toString();
    }

    public static void main(String[] args) throws FileNotFoundException {
        try {
            Map<String, String> fileStrMap = FileUtils.processFilesInPath(ResourceUtils.getFile(xmlPayloadPath).getPath(), FileUtils.defaultFileReader);
            fileStrMap.forEach((fileName, fileStr) -> {
                String filePath = jsonPayloadPath + "/" + fileName + ".json";
                String jsonStr = convertXmlToJson(fileStr);
                FileUtils.writeFileToPath(filePath, jsonStr);
            });
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
