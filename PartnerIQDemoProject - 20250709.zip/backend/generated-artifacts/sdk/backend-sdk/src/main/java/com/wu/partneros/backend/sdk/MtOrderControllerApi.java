package com.wu.partneros.backend.sdk;

import com.wu.partneros.backend.ApiClient;

import com.wu.partneros.backend.sdk.model.ConfirmOrderReply;
import com.wu.partneros.backend.sdk.model.ConfirmOrderRequest;
import com.wu.partneros.backend.sdk.model.CreateOrderReply;
import com.wu.partneros.backend.sdk.model.CreateOrderRequest;
import com.wu.partneros.backend.sdk.model.QuoteOrderReply;
import com.wu.partneros.backend.sdk.model.QuoteOrderRequest;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Flux;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2025-07-08T19:28:27.727699400-04:00[America/Toronto]", comments = "Generator version: 7.14.0")
public class MtOrderControllerApi {
    private ApiClient apiClient;

    public MtOrderControllerApi() {
        this(new ApiClient());
    }

    public MtOrderControllerApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    
    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param createOrderRequest The createOrderRequest parameter
     * @return CreateOrderReply
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec createOrderRequestCreation(@javax.annotation.Nonnull CreateOrderRequest createOrderRequest) throws WebClientResponseException {
        Object postBody = createOrderRequest;
        // verify the required parameter 'createOrderRequest' is set
        if (createOrderRequest == null) {
            throw new WebClientResponseException("Missing the required parameter 'createOrderRequest' when calling createOrder", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] localVarAccepts = { 
            "*/*"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { 
            "application/json"
        };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] {  };

        ParameterizedTypeReference<CreateOrderReply> localVarReturnType = new ParameterizedTypeReference<CreateOrderReply>() {};
        return apiClient.invokeAPI("/order/create", HttpMethod.POST, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param createOrderRequest The createOrderRequest parameter
     * @return CreateOrderReply
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<CreateOrderReply> createOrder(@javax.annotation.Nonnull CreateOrderRequest createOrderRequest) throws WebClientResponseException {
        ParameterizedTypeReference<CreateOrderReply> localVarReturnType = new ParameterizedTypeReference<CreateOrderReply>() {};
        return createOrderRequestCreation(createOrderRequest).bodyToMono(localVarReturnType);
    }

    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param createOrderRequest The createOrderRequest parameter
     * @return ResponseEntity&lt;CreateOrderReply&gt;
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<ResponseEntity<CreateOrderReply>> createOrderWithHttpInfo(@javax.annotation.Nonnull CreateOrderRequest createOrderRequest) throws WebClientResponseException {
        ParameterizedTypeReference<CreateOrderReply> localVarReturnType = new ParameterizedTypeReference<CreateOrderReply>() {};
        return createOrderRequestCreation(createOrderRequest).toEntity(localVarReturnType);
    }

    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param createOrderRequest The createOrderRequest parameter
     * @return ResponseSpec
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public ResponseSpec createOrderWithResponseSpec(@javax.annotation.Nonnull CreateOrderRequest createOrderRequest) throws WebClientResponseException {
        return createOrderRequestCreation(createOrderRequest);
    }

    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param confirmOrderRequest The confirmOrderRequest parameter
     * @return ConfirmOrderReply
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec createOrder1RequestCreation(@javax.annotation.Nonnull ConfirmOrderRequest confirmOrderRequest) throws WebClientResponseException {
        Object postBody = confirmOrderRequest;
        // verify the required parameter 'confirmOrderRequest' is set
        if (confirmOrderRequest == null) {
            throw new WebClientResponseException("Missing the required parameter 'confirmOrderRequest' when calling createOrder1", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] localVarAccepts = { 
            "*/*"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { 
            "application/json"
        };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] {  };

        ParameterizedTypeReference<ConfirmOrderReply> localVarReturnType = new ParameterizedTypeReference<ConfirmOrderReply>() {};
        return apiClient.invokeAPI("/order/confirm", HttpMethod.POST, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param confirmOrderRequest The confirmOrderRequest parameter
     * @return ConfirmOrderReply
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<ConfirmOrderReply> createOrder1(@javax.annotation.Nonnull ConfirmOrderRequest confirmOrderRequest) throws WebClientResponseException {
        ParameterizedTypeReference<ConfirmOrderReply> localVarReturnType = new ParameterizedTypeReference<ConfirmOrderReply>() {};
        return createOrder1RequestCreation(confirmOrderRequest).bodyToMono(localVarReturnType);
    }

    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param confirmOrderRequest The confirmOrderRequest parameter
     * @return ResponseEntity&lt;ConfirmOrderReply&gt;
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<ResponseEntity<ConfirmOrderReply>> createOrder1WithHttpInfo(@javax.annotation.Nonnull ConfirmOrderRequest confirmOrderRequest) throws WebClientResponseException {
        ParameterizedTypeReference<ConfirmOrderReply> localVarReturnType = new ParameterizedTypeReference<ConfirmOrderReply>() {};
        return createOrder1RequestCreation(confirmOrderRequest).toEntity(localVarReturnType);
    }

    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param confirmOrderRequest The confirmOrderRequest parameter
     * @return ResponseSpec
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public ResponseSpec createOrder1WithResponseSpec(@javax.annotation.Nonnull ConfirmOrderRequest confirmOrderRequest) throws WebClientResponseException {
        return createOrder1RequestCreation(confirmOrderRequest);
    }

    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param quoteOrderRequest The quoteOrderRequest parameter
     * @return QuoteOrderReply
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec quoteOrderRequestCreation(@javax.annotation.Nonnull QuoteOrderRequest quoteOrderRequest) throws WebClientResponseException {
        Object postBody = quoteOrderRequest;
        // verify the required parameter 'quoteOrderRequest' is set
        if (quoteOrderRequest == null) {
            throw new WebClientResponseException("Missing the required parameter 'quoteOrderRequest' when calling quoteOrder", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] localVarAccepts = { 
            "*/*"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { 
            "application/json"
        };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] {  };

        ParameterizedTypeReference<QuoteOrderReply> localVarReturnType = new ParameterizedTypeReference<QuoteOrderReply>() {};
        return apiClient.invokeAPI("/order/quote", HttpMethod.POST, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param quoteOrderRequest The quoteOrderRequest parameter
     * @return QuoteOrderReply
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<QuoteOrderReply> quoteOrder(@javax.annotation.Nonnull QuoteOrderRequest quoteOrderRequest) throws WebClientResponseException {
        ParameterizedTypeReference<QuoteOrderReply> localVarReturnType = new ParameterizedTypeReference<QuoteOrderReply>() {};
        return quoteOrderRequestCreation(quoteOrderRequest).bodyToMono(localVarReturnType);
    }

    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param quoteOrderRequest The quoteOrderRequest parameter
     * @return ResponseEntity&lt;QuoteOrderReply&gt;
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<ResponseEntity<QuoteOrderReply>> quoteOrderWithHttpInfo(@javax.annotation.Nonnull QuoteOrderRequest quoteOrderRequest) throws WebClientResponseException {
        ParameterizedTypeReference<QuoteOrderReply> localVarReturnType = new ParameterizedTypeReference<QuoteOrderReply>() {};
        return quoteOrderRequestCreation(quoteOrderRequest).toEntity(localVarReturnType);
    }

    /**
     * 
     * 
     * <p><b>200</b> - OK
     * @param quoteOrderRequest The quoteOrderRequest parameter
     * @return ResponseSpec
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public ResponseSpec quoteOrderWithResponseSpec(@javax.annotation.Nonnull QuoteOrderRequest quoteOrderRequest) throws WebClientResponseException {
        return quoteOrderRequestCreation(quoteOrderRequest);
    }
}
