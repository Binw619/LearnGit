

# Name


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**nameType** | **String** |  |  [optional] |
|**lastName** | **String** |  |  [optional] |
|**firstName** | **String** |  |  [optional] |



