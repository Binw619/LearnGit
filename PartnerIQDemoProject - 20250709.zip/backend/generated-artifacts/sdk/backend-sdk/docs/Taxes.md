

# Taxes


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**municipalTax** | **Integer** |  |  [optional] |
|**countyTax** | **Integer** |  |  [optional] |
|**stateTax** | **Integer** |  |  [optional] |
|**taxWorksheet** | **String** |  |  [optional] |
|**taxRate** | **Integer** |  |  [optional] |



