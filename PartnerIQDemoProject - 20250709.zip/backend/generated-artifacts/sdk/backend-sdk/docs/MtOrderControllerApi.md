# MtOrderControllerApi

All URIs are relative to *http://localhost:9091*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**createOrder**](MtOrderControllerApi.md#createOrder) | **POST** /order/create |  |
| [**createOrder1**](MtOrderControllerApi.md#createOrder1) | **POST** /order/confirm |  |
| [**quoteOrder**](MtOrderControllerApi.md#quoteOrder) | **POST** /order/quote |  |



## createOrder

> CreateOrderReply createOrder(createOrderRequest)



### Example

```java
// Import classes:
import com.wu.partneros.backend.ApiClient;
import com.wu.partneros.backend.ApiException;
import com.wu.partneros.backend.Configuration;
import com.wu.partneros.backend.models.*;
import com.wu.partneros.backend.sdk.MtOrderControllerApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://localhost:9091");

        MtOrderControllerApi apiInstance = new MtOrderControllerApi(defaultClient);
        CreateOrderRequest createOrderRequest = new CreateOrderRequest(); // CreateOrderRequest | 
        try {
            CreateOrderReply result = apiInstance.createOrder(createOrderRequest);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling MtOrderControllerApi#createOrder");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **createOrderRequest** | [**CreateOrderRequest**](CreateOrderRequest.md)|  | |

### Return type

[**CreateOrderReply**](CreateOrderReply.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: */*


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |


## createOrder1

> ConfirmOrderReply createOrder1(confirmOrderRequest)



### Example

```java
// Import classes:
import com.wu.partneros.backend.ApiClient;
import com.wu.partneros.backend.ApiException;
import com.wu.partneros.backend.Configuration;
import com.wu.partneros.backend.models.*;
import com.wu.partneros.backend.sdk.MtOrderControllerApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://localhost:9091");

        MtOrderControllerApi apiInstance = new MtOrderControllerApi(defaultClient);
        ConfirmOrderRequest confirmOrderRequest = new ConfirmOrderRequest(); // ConfirmOrderRequest | 
        try {
            ConfirmOrderReply result = apiInstance.createOrder1(confirmOrderRequest);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling MtOrderControllerApi#createOrder1");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **confirmOrderRequest** | [**ConfirmOrderRequest**](ConfirmOrderRequest.md)|  | |

### Return type

[**ConfirmOrderReply**](ConfirmOrderReply.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: */*


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |


## quoteOrder

> QuoteOrderReply quoteOrder(quoteOrderRequest)



### Example

```java
// Import classes:
import com.wu.partneros.backend.ApiClient;
import com.wu.partneros.backend.ApiException;
import com.wu.partneros.backend.Configuration;
import com.wu.partneros.backend.models.*;
import com.wu.partneros.backend.sdk.MtOrderControllerApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://localhost:9091");

        MtOrderControllerApi apiInstance = new MtOrderControllerApi(defaultClient);
        QuoteOrderRequest quoteOrderRequest = new QuoteOrderRequest(); // QuoteOrderRequest | 
        try {
            QuoteOrderReply result = apiInstance.quoteOrder(quoteOrderRequest);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling MtOrderControllerApi#quoteOrder");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **quoteOrderRequest** | [**QuoteOrderRequest**](QuoteOrderRequest.md)|  | |

### Return type

[**QuoteOrderReply**](QuoteOrderReply.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: */*


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |

