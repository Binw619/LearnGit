

# PaymentDetails


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**messageCharges** | **String** |  |  [optional] |
|**fees** | [**Fees**](Fees.md) |  |  [optional] |
|**exchangeRate** | **Double** |  |  [optional] |
|**origination** | [**Origination**](Origination.md) |  |  [optional] |
|**paymentDigest** | **String** |  |  [optional] |
|**destination** | [**Destination**](Destination.md) |  |  [optional] |
|**taxes** | [**Taxes**](Taxes.md) |  |  [optional] |
|**promotion** | [**Promotion**](Promotion.md) |  |  [optional] |



