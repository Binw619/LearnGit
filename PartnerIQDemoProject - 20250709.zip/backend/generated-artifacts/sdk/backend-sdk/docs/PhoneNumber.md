

# PhoneNumber


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**countryCode** | **Integer** |  |  [optional] |
|**nationalNumber** | **Long** |  |  [optional] |



