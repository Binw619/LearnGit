

# Origination


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**countryIsoCode** | **String** |  |  [optional] |
|**currencyIsoCode** | **String** |  |  [optional] |
|**principalAmount** | **Integer** |  |  [optional] |



