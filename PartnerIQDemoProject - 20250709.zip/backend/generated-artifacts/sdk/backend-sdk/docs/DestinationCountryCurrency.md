

# DestinationCountryCurrency


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**isoCode** | [**IsoCode**](IsoCode.md) |  |  [optional] |



