

# Receiver


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**reasonForSending** | **Integer** |  |  [optional] |
|**address** | [**Address**](Address.md) |  |  [optional] |
|**contactPhone** | **Long** |  |  [optional] |
|**mobilePhone** | [**MobilePhone**](MobilePhone.md) |  |  [optional] |
|**name** | [**Name**](Name.md) |  |  [optional] |



