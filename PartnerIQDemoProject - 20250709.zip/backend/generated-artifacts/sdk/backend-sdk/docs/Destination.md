

# Destination


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**expectedPayoutAmount** | **Integer** |  |  [optional] |
|**countryIsoCode** | **String** |  |  [optional] |
|**currencyIsoCode** | **String** |  |  [optional] |



