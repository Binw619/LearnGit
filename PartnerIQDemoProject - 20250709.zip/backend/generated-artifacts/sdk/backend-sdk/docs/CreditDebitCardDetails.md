

# CreditDebitCardDetails


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**authorizationCode** | **String** |  |  [optional] |



