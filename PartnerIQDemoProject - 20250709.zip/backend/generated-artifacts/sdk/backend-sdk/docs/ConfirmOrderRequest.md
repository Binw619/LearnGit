

# ConfirmOrderRequest


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**financials** | [**Financials**](Financials.md) |  |  [optional] |
|**mtcn** | **Integer** |  |  [optional] |
|**receiver** | [**Receiver**](Receiver.md) |  |  [optional] |
|**paymentDetails** | [**PaymentDetails2**](PaymentDetails2.md) |  |  [optional] |
|**newMtcn** | **Long** |  |  [optional] |
|**sender** | [**Sender**](Sender.md) |  |  [optional] |
|**bankDetails** | [**BankDetails**](BankDetails.md) |  |  [optional] |
|**deliveryServices** | [**DeliveryServices**](DeliveryServices.md) |  |  [optional] |



