

# IdDetails


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**idNumber** | **String** |  |  [optional] |
|**idCountryOfIssue** | **String** |  |  [optional] |
|**idType** | **String** |  |  [optional] |



