

# CreateOrderRequest


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**financials** | [**Financials**](Financials.md) |  |  [optional] |
|**receiver** | [**Receiver**](Receiver.md) |  |  [optional] |
|**paymentDetails** | [**PaymentDetails**](PaymentDetails.md) |  |  [optional] |
|**sender** | [**Sender**](Sender.md) |  |  [optional] |
|**bankDetails** | [**BankDetails**](BankDetails.md) |  |  [optional] |
|**deliveryServices** | [**DeliveryServices**](DeliveryServices.md) |  |  [optional] |



