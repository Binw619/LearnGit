

# PaymentDetails2


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**exchangeRate** | **Double** |  |  [optional] |
|**fixOnSend** | **String** |  |  [optional] |
|**duplicateDetectionFlag** | **String** |  |  [optional] |
|**destinationCountryCurrency** | [**DestinationCountryCurrency**](DestinationCountryCurrency.md) |  |  [optional] |
|**stagePayFields** | [**StagePayFields**](StagePayFields.md) |  |  [optional] |
|**recordingCountryCurrency** | [**RecordingCountryCurrency**](RecordingCountryCurrency.md) |  |  [optional] |
|**transactionType** | **String** |  |  [optional] |
|**expectedPayoutLocation** | **String** |  |  [optional] |
|**creditDebitCardDetails** | [**CreditDebitCardDetails**](CreditDebitCardDetails.md) |  |  [optional] |
|**originatingState** | **String** |  |  [optional] |
|**originatingCity** | **String** |  |  [optional] |
|**mtRequestedStatus** | **String** |  |  [optional] |
|**originatingCountryCurrency** | [**OriginatingCountryCurrency**](OriginatingCountryCurrency.md) |  |  [optional] |
|**paymentType** | **String** |  |  [optional] |
|**payWoIdIndicator** | **String** |  |  [optional] |



