

# CreateOrderReply


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**financials** | [**Financials**](Financials.md) |  |  [optional] |
|**mtcn** | **Integer** |  |  [optional] |
|**promotions** | [**Promotions**](Promotions.md) |  |  [optional] |
|**receiver** | [**Receiver**](Receiver.md) |  |  [optional] |
|**paymentDetails** | [**PaymentDetails**](PaymentDetails.md) |  |  [optional] |
|**newMtcn** | **Long** |  |  [optional] |
|**sender** | [**Sender**](Sender.md) |  |  [optional] |



