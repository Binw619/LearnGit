

# BankDetails


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**accountNumber** | **Long** |  |  [optional] |
|**name** | **String** |  |  [optional] |
|**routingNumber** | **String** |  |  [optional] |



