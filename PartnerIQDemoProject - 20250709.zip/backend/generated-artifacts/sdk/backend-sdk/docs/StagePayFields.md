

# StagePayFields


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**snpIndicator** | **String** |  |  [optional] |
|**stagingBuffer** | **String** |  |  [optional] |



