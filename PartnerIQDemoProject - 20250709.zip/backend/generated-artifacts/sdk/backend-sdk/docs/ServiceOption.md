

# ServiceOption


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**paymentDetails** | [**PaymentDetails**](PaymentDetails.md) |  |  [optional] |
|**wuProduct** | [**WuProduct**](WuProduct.md) |  |  [optional] |
|**transactionType** | **String** |  |  [optional] |



