

# MobilePhone


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**phoneNumber** | [**PhoneNumber**](PhoneNumber.md) |  |  [optional] |



