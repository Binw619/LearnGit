

# WuProduct


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**code** | **Integer** |  |  [optional] |
|**name** | **String** |  |  [optional] |
|**routingCode** | **String** |  |  [optional] |
|**type** | **String** |  |  [optional] |



