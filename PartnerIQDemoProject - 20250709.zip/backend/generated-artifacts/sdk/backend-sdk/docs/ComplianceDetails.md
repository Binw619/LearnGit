

# ComplianceDetails


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**dateOfBirth** | **Integer** |  |  [optional] |
|**doesTheIDHaveAnExpirationDate** | **String** |  |  [optional] |
|**templateId** | **String** |  |  [optional] |
|**countryOfBirth** | **String** |  |  [optional] |
|**idDetails** | [**IdDetails**](IdDetails.md) |  |  [optional] |
|**idExpirationDate** | **String** |  |  [optional] |
|**ackFlag** | **String** |  |  [optional] |



