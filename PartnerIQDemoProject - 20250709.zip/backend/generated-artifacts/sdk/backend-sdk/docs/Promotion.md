

# Promotion


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**discount** | **Integer** |  |  [optional] |
|**status** | **Integer** |  |  [optional] |



