

# Sender


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**address** | [**Address**](Address.md) |  |  [optional] |
|**complianceDetails** | [**ComplianceDetails**](ComplianceDetails.md) |  |  [optional] |
|**contactPhone** | **Long** |  |  [optional] |
|**mobilePhone** | [**MobilePhone**](MobilePhone.md) |  |  [optional] |
|**name** | [**Name**](Name.md) |  |  [optional] |
|**preferredCustomer** | **String** |  |  [optional] |
|**email** | **String** |  |  [optional] |



