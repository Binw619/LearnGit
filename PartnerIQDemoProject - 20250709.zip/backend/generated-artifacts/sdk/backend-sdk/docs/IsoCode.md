

# IsoCode


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**countryCode** | **String** |  |  [optional] |
|**currencyCode** | **String** |  |  [optional] |



