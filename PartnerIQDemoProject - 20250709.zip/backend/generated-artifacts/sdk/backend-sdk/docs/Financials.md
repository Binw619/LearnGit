

# Financials


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**grossTotalAmount** | **Integer** |  |  [optional] |
|**moneyTransferLimit** | **Long** |  |  [optional] |
|**payAmount** | **Integer** |  |  [optional] |
|**messageCharge** | **Integer** |  |  [optional] |
|**taxes** | [**Taxes**](Taxes.md) |  |  [optional] |
|**destinationPrincipalAmount** | **Integer** |  |  [optional] |
|**originatorsPrincipalAmount** | **Integer** |  |  [optional] |
|**originatingCurrencyPrincipal** | **String** |  |  [optional] |
|**plusChargesAmount** | **Integer** |  |  [optional] |
|**tolls** | **Integer** |  |  [optional] |
|**charges** | **Integer** |  |  [optional] |
|**totalUndiscountedCharges** | **Integer** |  |  [optional] |
|**canadianDollarExchangeFee** | **Integer** |  |  [optional] |
|**totalDiscountedCharges** | **Integer** |  |  [optional] |



