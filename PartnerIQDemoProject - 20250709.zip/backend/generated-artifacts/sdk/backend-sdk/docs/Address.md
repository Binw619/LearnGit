

# Address


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**countryCode** | [**CountryCode**](CountryCode.md) |  |  [optional] |
|**addrLine1** | **String** |  |  [optional] |
|**city** | **String** |  |  [optional] |
|**state** | **String** |  |  [optional] |
|**postalCode** | **Integer** |  |  [optional] |



