

# ServiceOptions


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**serviceOption** | [**List&lt;ServiceOption&gt;**](ServiceOption.md) |  |  [optional] |



