# CustomerKycControllerApi

All URIs are relative to *http://localhost:9091*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**getCustomerKYCById**](CustomerKycControllerApi.md#getCustomerKYCById) | **GET** /customer/kyc/lookup |  |
| [**getKycTemplate**](CustomerKycControllerApi.md#getKycTemplate) | **GET** /customer/kyc/template |  |



## getCustomerKYCById

> Sender getCustomerKYCById(customerId, firstname, lastname)



### Example

```java
// Import classes:
import com.wu.partneros.backend.ApiClient;
import com.wu.partneros.backend.ApiException;
import com.wu.partneros.backend.Configuration;
import com.wu.partneros.backend.models.*;
import com.wu.partneros.backend.sdk.CustomerKycControllerApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://localhost:9091");

        CustomerKycControllerApi apiInstance = new CustomerKycControllerApi(defaultClient);
        String customerId = "customerId_example"; // String | 
        String firstname = "firstname_example"; // String | 
        String lastname = "lastname_example"; // String | 
        try {
            Sender result = apiInstance.getCustomerKYCById(customerId, firstname, lastname);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling CustomerKycControllerApi#getCustomerKYCById");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **customerId** | **String**|  | |
| **firstname** | **String**|  | |
| **lastname** | **String**|  | |

### Return type

[**Sender**](Sender.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: */*


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |


## getKycTemplate

> String getKycTemplate(countryCode)



### Example

```java
// Import classes:
import com.wu.partneros.backend.ApiClient;
import com.wu.partneros.backend.ApiException;
import com.wu.partneros.backend.Configuration;
import com.wu.partneros.backend.models.*;
import com.wu.partneros.backend.sdk.CustomerKycControllerApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("http://localhost:9091");

        CustomerKycControllerApi apiInstance = new CustomerKycControllerApi(defaultClient);
        String countryCode = "countryCode_example"; // String | 
        try {
            String result = apiInstance.getKycTemplate(countryCode);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling CustomerKycControllerApi#getKycTemplate");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **countryCode** | **String**|  | |

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: */*


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | OK |  -  |

