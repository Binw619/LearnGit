

# CountryCode


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**countryName** | **String** |  |  [optional] |
|**isoCode** | [**IsoCode**](IsoCode.md) |  |  [optional] |



