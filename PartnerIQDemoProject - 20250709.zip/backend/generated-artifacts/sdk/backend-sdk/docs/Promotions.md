

# Promotions


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**promoMessage** | **String** |  |  [optional] |
|**promoCodeDescription** | **String** |  |  [optional] |
|**senderPromoCode** | **String** |  |  [optional] |



