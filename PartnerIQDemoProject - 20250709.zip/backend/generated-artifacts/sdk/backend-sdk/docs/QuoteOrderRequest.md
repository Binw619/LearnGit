

# QuoteOrderRequest


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**paymentDetails** | [**PaymentDetails**](PaymentDetails.md) |  |  [optional] |
|**sender** | [**Sender**](Sender.md) |  |  [optional] |
|**transactionType** | **String** |  |  [optional] |



