

# QuoteOrderReply


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**serviceOptions** | [**ServiceOptions**](ServiceOptions.md) |  |  [optional] |
|**sender** | [**Sender**](Sender.md) |  |  [optional] |



