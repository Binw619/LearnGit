

# DeliveryServices


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**code** | **Integer** |  |  [optional] |
|**paymentDigest** | **String** |  |  [optional] |
|**information** | **String** |  |  [optional] |
|**routingCode** | **String** |  |  [optional] |



