

# Fees


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**charges** | **Integer** |  |  [optional] |
|**deliveryCharges** | **Integer** |  |  [optional] |
|**otherCharges** | **Integer** |  |  [optional] |



