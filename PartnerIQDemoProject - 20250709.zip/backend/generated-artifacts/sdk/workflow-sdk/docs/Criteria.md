

# Criteria


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**context** | **String** |  |  [optional] |
|**condition** | **String** |  |  |
|**type** | **String** |  |  [optional] |
|**next** | **ModuleName** |  |  |



