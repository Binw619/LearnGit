

# ModuleMetaApi


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**uri** | **String** | URI of the Meta API |  [optional] |
|**headers** | [**List&lt;Headers&gt;**](Headers.md) |  |  [optional] |
|**body** | [**MetaRequestBody**](MetaRequestBody.md) |  |  [optional] |



