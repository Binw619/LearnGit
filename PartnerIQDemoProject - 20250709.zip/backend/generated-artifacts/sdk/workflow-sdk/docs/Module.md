

# Module


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **ModuleName** |  |  |
|**pathName** | **String** |  |  [optional] |
|**pathUri** | **String** |  |  [optional] |
|**isMandatory** | **Boolean** |  |  [optional] |
|**caching** | [**ModuleCaching**](ModuleCaching.md) |  |  [optional] |
|**metaRequired** | **Boolean** |  |  [optional] |
|**metaApi** | [**ModuleMetaApi**](ModuleMetaApi.md) |  |  [optional] |
|**successCriterias** | [**Criteria**](Criteria.md) |  |  |
|**failureCriterias** | [**FailureCriteria**](FailureCriteria.md) |  |  [optional] |



