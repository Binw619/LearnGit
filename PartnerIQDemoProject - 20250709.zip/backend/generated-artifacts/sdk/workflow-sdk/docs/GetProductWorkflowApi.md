# GetProductWorkflowApi

All URIs are relative to *https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_workflow_v1_api/1.0.0*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**getProductWorkflow**](GetProductWorkflowApi.md#getProductWorkflow) | **GET** /v1/partneros/workflow |  |



## getProductWorkflow

> WorkflowResponse getProductWorkflow(productName)



This API facilitates the partner to search the list of the modules and their corresponding request fields and API details for a given product type and use case combination. It also provides if the response should be cached by partner and if so, for how much time.

### Example

```java
// Import classes:
import com.wu.partneros.workflow.ApiClient;
import com.wu.partneros.workflow.ApiException;
import com.wu.partneros.workflow.Configuration;
import com.wu.partneros.workflow.models.*;
import com.wu.partneros.workflow.sdk.GetProductWorkflowApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_workflow_v1_api/1.0.0");

        GetProductWorkflowApi apiInstance = new GetProductWorkflowApi(defaultClient);
        Product productName = Product.fromValue("SENDMONEY"); // Product | Name of the product to build the workflow API
        try {
            WorkflowResponse result = apiInstance.getProductWorkflow(productName);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling GetProductWorkflowApi#getProductWorkflow");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **productName** | [**Product**](.md)| Name of the product to build the workflow API | [optional] [default to SENDMONEY] [enum: SENDMONEY, RECEIVEMONEY] |

### Return type

[**WorkflowResponse**](WorkflowResponse.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Successful Operation |  * x-wu-externalRefId - The external Reference Id sent by calling application in request header. <br>  * x-wu-correlationID - Internal Reference Id generated for internal tracking purpose. <br>  |
| **400** | Bad Request |  * x-wu-externalRefId - The external Reference Id sent by calling application in request header. <br>  |
| **500** | Internal Server Error |  * x-wu-externalRefId - The external Reference Id sent by calling application in request header. <br>  |

