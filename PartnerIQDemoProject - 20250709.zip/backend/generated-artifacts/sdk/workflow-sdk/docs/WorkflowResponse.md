

# WorkflowResponse

Workflow response for the given use case

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**modules** | [**Module**](Module.md) |  |  [optional] |



