

# MetaRequestBody


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**moudle** | **String** |  |  [optional] |
|**path** | **String** |  |  [optional] |
|**fields** | [**MetaRequestField**](MetaRequestField.md) |  |  [optional] |



