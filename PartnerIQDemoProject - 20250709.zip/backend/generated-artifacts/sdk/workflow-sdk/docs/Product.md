

# Product

## Enum


* `SENDMONEY` (value: `"SENDMONEY"`)

* `RECEIVEMONEY` (value: `"RECEIVEMONEY"`)



