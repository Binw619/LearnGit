

# Headers


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**module** | **String** |  |  [optional] |
|**path** | **String** |  |  [optional] |



