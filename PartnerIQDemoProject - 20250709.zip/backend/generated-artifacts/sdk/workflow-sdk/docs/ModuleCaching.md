

# ModuleCaching


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**isEnabled** | **Boolean** |  |  [optional] |
|**ttl** | **String** |  |  [optional] |



