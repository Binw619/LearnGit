

# FailureCriteria


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**context** | **String** |  |  [optional] |
|**condition** | **String** |  |  [optional] |
|**type** | **String** |  |  [optional] |
|**retryAfter** | **BigDecimal** |  |  [optional] |
|**retryLimit** | **Integer** |  |  [optional] |
|**next** | **ModuleName** |  |  [optional] |



