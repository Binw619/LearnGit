package com.wu.partneros.catalog.sdk;

import com.wu.partneros.catalog.ApiClient;

import com.wu.partneros.catalog.sdk.model.Errors;
import com.wu.partneros.catalog.sdk.model.ModuleCatalogResponse;
import com.wu.partneros.catalog.sdk.model.ProductCatalogResponse;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Flux;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2025-07-08T19:27:54.474105500-04:00[America/Toronto]", comments = "Generator version: 7.14.0")
public class CatalogApiApi {
    private ApiClient apiClient;

    public CatalogApiApi() {
        this(new ApiClient());
    }

    public CatalogApiApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    
    /**
     * 
     * Returns list of all Western Union Products for Money Transfer and Payments
     * <p><b>200</b> - Search results matching criteria
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @return ProductCatalogResponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec getProductCatalogRequestCreation() throws WebClientResponseException {
        Object postBody = null;
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] {  };

        ParameterizedTypeReference<ProductCatalogResponse> localVarReturnType = new ParameterizedTypeReference<ProductCatalogResponse>() {};
        return apiClient.invokeAPI("/v1/partneros/products", HttpMethod.GET, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * 
     * Returns list of all Western Union Products for Money Transfer and Payments
     * <p><b>200</b> - Search results matching criteria
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @return ProductCatalogResponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<ProductCatalogResponse> getProductCatalog() throws WebClientResponseException {
        ParameterizedTypeReference<ProductCatalogResponse> localVarReturnType = new ParameterizedTypeReference<ProductCatalogResponse>() {};
        return getProductCatalogRequestCreation().bodyToMono(localVarReturnType);
    }

    /**
     * 
     * Returns list of all Western Union Products for Money Transfer and Payments
     * <p><b>200</b> - Search results matching criteria
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @return ResponseEntity&lt;ProductCatalogResponse&gt;
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<ResponseEntity<ProductCatalogResponse>> getProductCatalogWithHttpInfo() throws WebClientResponseException {
        ParameterizedTypeReference<ProductCatalogResponse> localVarReturnType = new ParameterizedTypeReference<ProductCatalogResponse>() {};
        return getProductCatalogRequestCreation().toEntity(localVarReturnType);
    }

    /**
     * 
     * Returns list of all Western Union Products for Money Transfer and Payments
     * <p><b>200</b> - Search results matching criteria
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @return ResponseSpec
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public ResponseSpec getProductCatalogWithResponseSpec() throws WebClientResponseException {
        return getProductCatalogRequestCreation();
    }

    /**
     * 
     * Returns list of all Modules in a Product
     * <p><b>200</b> - Search results matching criteria
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param productName The productName parameter
     * @param moduleName The moduleName parameter
     * @return ModuleCatalogResponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec getProductModuleCatalogRequestCreation(@javax.annotation.Nullable String productName, @javax.annotation.Nullable String moduleName) throws WebClientResponseException {
        Object postBody = null;
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();

        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "productName", productName));
        queryParams.putAll(apiClient.parameterToMultiValueMap(null, "moduleName", moduleName));
        
        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] {  };

        ParameterizedTypeReference<ModuleCatalogResponse> localVarReturnType = new ParameterizedTypeReference<ModuleCatalogResponse>() {};
        return apiClient.invokeAPI("/v1/partneros/product/catalog", HttpMethod.GET, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * 
     * Returns list of all Modules in a Product
     * <p><b>200</b> - Search results matching criteria
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param productName The productName parameter
     * @param moduleName The moduleName parameter
     * @return ModuleCatalogResponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<ModuleCatalogResponse> getProductModuleCatalog(@javax.annotation.Nullable String productName, @javax.annotation.Nullable String moduleName) throws WebClientResponseException {
        ParameterizedTypeReference<ModuleCatalogResponse> localVarReturnType = new ParameterizedTypeReference<ModuleCatalogResponse>() {};
        return getProductModuleCatalogRequestCreation(productName, moduleName).bodyToMono(localVarReturnType);
    }

    /**
     * 
     * Returns list of all Modules in a Product
     * <p><b>200</b> - Search results matching criteria
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param productName The productName parameter
     * @param moduleName The moduleName parameter
     * @return ResponseEntity&lt;ModuleCatalogResponse&gt;
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<ResponseEntity<ModuleCatalogResponse>> getProductModuleCatalogWithHttpInfo(@javax.annotation.Nullable String productName, @javax.annotation.Nullable String moduleName) throws WebClientResponseException {
        ParameterizedTypeReference<ModuleCatalogResponse> localVarReturnType = new ParameterizedTypeReference<ModuleCatalogResponse>() {};
        return getProductModuleCatalogRequestCreation(productName, moduleName).toEntity(localVarReturnType);
    }

    /**
     * 
     * Returns list of all Modules in a Product
     * <p><b>200</b> - Search results matching criteria
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param productName The productName parameter
     * @param moduleName The moduleName parameter
     * @return ResponseSpec
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public ResponseSpec getProductModuleCatalogWithResponseSpec(@javax.annotation.Nullable String productName, @javax.annotation.Nullable String moduleName) throws WebClientResponseException {
        return getProductModuleCatalogRequestCreation(productName, moduleName);
    }
}
