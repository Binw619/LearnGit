

# Module


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**paths** | [**Path**](Path.md) |  |  [optional] |



