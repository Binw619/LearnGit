

# Field


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**label** | **String** |  |  [optional] |
|**length** | **Integer** |  |  [optional] |
|**uiFieldType** | [**UiFieldTypeEnum**](#UiFieldTypeEnum) |  |  [optional] |
|**uriIdentifier** | **String** |  |  [optional] |
|**format** | **String** |  |  [optional] |
|**description** | **String** |  |  [optional] |
|**min** | **String** |  |  [optional] |
|**max** | **String** |  |  [optional] |
|**validations** | **Validations** |  |  [optional] |



## Enum: UiFieldTypeEnum

| Name | Value |
|---- | -----|
| STRING | &quot;string&quot; |
| NUMBER | &quot;number&quot; |
| INTEGER | &quot;integer&quot; |
| BOOLEAN | &quot;boolean&quot; |



