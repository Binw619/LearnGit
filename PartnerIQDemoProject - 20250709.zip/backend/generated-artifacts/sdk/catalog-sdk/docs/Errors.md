

# Errors


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**errorCode** | **String** |  |  [optional] |
|**errorMessage** | **String** |  |  [optional] |



