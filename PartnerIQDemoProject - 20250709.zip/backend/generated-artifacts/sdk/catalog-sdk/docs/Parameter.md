

# Parameter


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**scope** | [**ScopeEnum**](#ScopeEnum) |  |  [optional] |
|**description** | **String** |  |  [optional] |
|**required** | **Boolean** |  |  [optional] |
|**type** | **String** |  |  [optional] |



## Enum: ScopeEnum

| Name | Value |
|---- | -----|
| QUERY | &quot;Query&quot; |
| PATH | &quot;Path&quot; |



