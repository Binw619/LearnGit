

# Product


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**productName** | [**ProductNameEnum**](#ProductNameEnum) |  |  [optional] |
|**modules** | [**List&lt;ModulesEnum&gt;**](#List&lt;ModulesEnum&gt;) |  |  [optional] |



## Enum: ProductNameEnum

| Name | Value |
|---- | -----|
| SENDMONEY | &quot;SENDMONEY&quot; |
| RECEIVEMONEY | &quot;RECEIVEMONEY&quot; |



## Enum: List&lt;ModulesEnum&gt;

| Name | Value |
|---- | -----|
| CONFIG | &quot;Config&quot; |
| PRICING | &quot;Pricing&quot; |
| ORDER | &quot;Order&quot; |



