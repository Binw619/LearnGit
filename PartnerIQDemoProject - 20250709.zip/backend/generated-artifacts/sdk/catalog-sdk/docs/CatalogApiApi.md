# CatalogApiApi

All URIs are relative to *https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_workflow_v1_api/1.0.0*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**getProductCatalog**](CatalogApiApi.md#getProductCatalog) | **GET** /v1/partneros/products |  |
| [**getProductModuleCatalog**](CatalogApiApi.md#getProductModuleCatalog) | **GET** /v1/partneros/product/catalog |  |



## getProductCatalog

> ProductCatalogResponse getProductCatalog()



Returns list of all Western Union Products for Money Transfer and Payments

### Example

```java
// Import classes:
import com.wu.partneros.catalog.ApiClient;
import com.wu.partneros.catalog.ApiException;
import com.wu.partneros.catalog.Configuration;
import com.wu.partneros.catalog.models.*;
import com.wu.partneros.catalog.sdk.CatalogApiApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_workflow_v1_api/1.0.0");

        CatalogApiApi apiInstance = new CatalogApiApi(defaultClient);
        try {
            ProductCatalogResponse result = apiInstance.getProductCatalog();
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling CatalogApiApi#getProductCatalog");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters

This endpoint does not need any parameter.

### Return type

[**ProductCatalogResponse**](ProductCatalogResponse.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Search results matching criteria |  -  |
| **400** | Bad Request |  -  |
| **500** | Internal Server Error |  -  |


## getProductModuleCatalog

> ModuleCatalogResponse getProductModuleCatalog(productName, moduleName)



Returns list of all Modules in a Product

### Example

```java
// Import classes:
import com.wu.partneros.catalog.ApiClient;
import com.wu.partneros.catalog.ApiException;
import com.wu.partneros.catalog.Configuration;
import com.wu.partneros.catalog.models.*;
import com.wu.partneros.catalog.sdk.CatalogApiApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_workflow_v1_api/1.0.0");

        CatalogApiApi apiInstance = new CatalogApiApi(defaultClient);
        String productName = "SENDMONEY"; // String | 
        String moduleName = "Config"; // String | 
        try {
            ModuleCatalogResponse result = apiInstance.getProductModuleCatalog(productName, moduleName);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling CatalogApiApi#getProductModuleCatalog");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **productName** | **String**|  | [optional] [default to SENDMONEY] [enum: SENDMONEY, RECEIVEMONEY] |
| **moduleName** | **String**|  | [optional] [default to Order] [enum: Config, Pricing, Order] |

### Return type

[**ModuleCatalogResponse**](ModuleCatalogResponse.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Search results matching criteria |  -  |
| **400** | Bad Request |  -  |
| **500** | Internal Server Error |  -  |

