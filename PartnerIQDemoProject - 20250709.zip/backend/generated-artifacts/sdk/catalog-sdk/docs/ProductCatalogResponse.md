

# ProductCatalogResponse


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**products** | [**Product**](Product.md) |  |  [optional] |



