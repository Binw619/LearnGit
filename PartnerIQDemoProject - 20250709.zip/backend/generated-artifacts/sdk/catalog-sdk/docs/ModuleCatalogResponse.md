

# ModuleCatalogResponse


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**module** | [**Module**](Module.md) |  |  [optional] |
|**schemas** | [**Field**](Field.md) |  |  [optional] |



