

# Path


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**uri** | **String** |  |  [optional] |
|**type** | **String** |  |  [optional] |
|**header** | [**Header**](Header.md) |  |  [optional] |
|**parameters** | [**Parameter**](Parameter.md) |  |  [optional] |
|**requestFields** | [**FieldReference**](FieldReference.md) |  |  [optional] |
|**responseFields** | [**FieldReference**](FieldReference.md) |  |  [optional] |



