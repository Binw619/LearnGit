

# Field


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** |  |  [optional] |
|**label** | **String** |  |  [optional] |
|**length** | **Integer** |  |  [optional] |
|**uiFieldType** | **String** |  |  [optional] |
|**uriIdentifier** | **String** |  |  [optional] |
|**required** | [**RequiredEnum**](#RequiredEnum) |  |  [optional] |
|**conditions** | **Conditions** |  |  [optional] |
|**listValue** | [**ListValue**](ListValue.md) |  |  [optional] |
|**validations** | **Validations** |  |  [optional] |



## Enum: RequiredEnum

| Name | Value |
|---- | -----|
| M | &quot;M&quot; |
| C | &quot;C&quot; |
| O | &quot;O&quot; |



