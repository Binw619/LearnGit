

# Path

## Enum


* `ENTITLED_DESTIONATIONS` (value: `"entitledDestionations"`)

* `QUOTE` (value: `"quote"`)

* `CREATE` (value: `"create"`)

* `CONFIRM` (value: `"confirm"`)



