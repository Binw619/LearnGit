

# CreateOrderResponse


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**fieldsDetails** | [**FieldsDetails**](FieldsDetails.md) |  |  [optional] |



