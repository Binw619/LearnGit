

# DependentFieldList


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**fieldName** | **String** |  |  [optional] |
|**dependency** | **String** |  |  [optional] |
|**listValue** | [**ListValue**](ListValue.md) |  |  [optional] |



