

# Product

## Enum


* `SEND_MONEY` (value: `"SEND_MONEY"`)

* `RETAIL` (value: `"RETAIL"`)



