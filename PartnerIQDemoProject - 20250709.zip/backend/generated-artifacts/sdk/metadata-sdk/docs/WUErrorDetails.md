

# WUErrorDetails

Model representing WUError details - List of fields causing errors and their specific error messages

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**field** | **String** | field causing issue |  [optional] |
|**issue** | **String** | field specific issue description |  [optional] |



