

# Conditions


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**operation** | **String** |  |  [optional] |
|**valueList** | **ValueList** |  |  [optional] |
|**dependentFieldList** | **DependentFieldList** |  |  [optional] |



