

# CreateOrderRequestFields


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**senderCountry** | **String** |  |  [optional] |
|**senderCurrency** | **String** |  |  [optional] |
|**receiverCountry** | **String** |  |  [optional] |
|**receiverCurrency** | **String** |  |  [optional] |
|**attemptType** | **String** |  |  [optional] |



