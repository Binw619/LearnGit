

# Module

## Enum


* `CONFIG` (value: `"config"`)

* `PRICING` (value: `"pricing"`)

* `ORDER` (value: `"order"`)



