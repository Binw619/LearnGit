

# FieldsDetails


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**fields** | [**Field**](Field.md) |  |  [optional] |



