# PricingProductMetaApi

All URIs are relative to *https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_meta_v1_api/1.0.0*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**pricingMeta**](PricingProductMetaApi.md#pricingMeta) | **GET** /v1/partneros/meta/pricing/quote |  |



## pricingMeta

> QuoteResponse pricingMeta(module, path)



This API facilitates the partner to get the metadata required for the API. It provides the list of fields mandatory and optional

### Example

```java
// Import classes:
import com.wu.partneros.metadata.ApiClient;
import com.wu.partneros.metadata.ApiException;
import com.wu.partneros.metadata.Configuration;
import com.wu.partneros.metadata.models.*;
import com.wu.partneros.metadata.sdk.PricingProductMetaApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_meta_v1_api/1.0.0");

        PricingProductMetaApi apiInstance = new PricingProductMetaApi(defaultClient);
        String module = "pricing"; // String | 
        String path = "quote"; // String | 
        try {
            QuoteResponse result = apiInstance.pricingMeta(module, path);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling PricingProductMetaApi#pricingMeta");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **module** | **String**|  | [optional] [default to pricing] |
| **path** | **String**|  | [optional] [default to quote] |

### Return type

[**QuoteResponse**](QuoteResponse.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | successful operation |  * x-wu-externalRefId - The external Reference Id sent by calling application in request header. <br>  |
| **400** | Bad Request |  * x-wu-externalRefId - The external Reference Id sent by calling application in request header. <br>  |
| **500** | Internal Server Error |  * x-wu-externalRefId - The external Reference Id sent by calling application in request header. <br>  |

