

# ListValue


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**displayValue** | **String** |  |  [optional] |
|**id** | **String** |  |  [optional] |



