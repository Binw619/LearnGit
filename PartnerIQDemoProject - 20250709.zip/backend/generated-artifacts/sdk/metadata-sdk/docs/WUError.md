

# WUError

Model representing Western Union Error schema

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** | Unique name of the error |  [optional] |
|**message** | **String** | Message describing the error |  [optional] |
|**errorCode** | **String** | Syntactic Error code |  [optional] |
|**issues** | [**WUErrorDetails**](WUErrorDetails.md) |  |  [optional] |



