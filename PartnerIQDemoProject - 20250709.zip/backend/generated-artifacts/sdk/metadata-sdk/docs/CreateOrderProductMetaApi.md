# CreateOrderProductMetaApi

All URIs are relative to *https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_meta_v1_api/1.0.0*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**createOrderMeta**](CreateOrderProductMetaApi.md#createOrderMeta) | **POST** /v1/partneros/meta/order/create |  |



## createOrderMeta

> CreateOrderResponse createOrderMeta(body, xWuModule, xWuPath)



This API facilitates the partner to get the metadata required for the API. It provides the list of fields mandatory and optional

### Example

```java
// Import classes:
import com.wu.partneros.metadata.ApiClient;
import com.wu.partneros.metadata.ApiException;
import com.wu.partneros.metadata.Configuration;
import com.wu.partneros.metadata.models.*;
import com.wu.partneros.metadata.sdk.CreateOrderProductMetaApi;

public class Example {
    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setBasePath("https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_meta_v1_api/1.0.0");

        CreateOrderProductMetaApi apiInstance = new CreateOrderProductMetaApi(defaultClient);
        CreateOrderRequestFields body = new CreateOrderRequestFields(); // CreateOrderRequestFields | Accepts the Request Body from Smart Proxy
        String xWuModule = "order"; // String | Module of the Meta aPI
        String xWuPath = "create"; // String | Module of the Meta aPI
        try {
            CreateOrderResponse result = apiInstance.createOrderMeta(body, xWuModule, xWuPath);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling CreateOrderProductMetaApi#createOrderMeta");
            System.err.println("Status code: " + e.getCode());
            System.err.println("Reason: " + e.getResponseBody());
            System.err.println("Response headers: " + e.getResponseHeaders());
            e.printStackTrace();
        }
    }
}
```

### Parameters


| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **body** | **CreateOrderRequestFields**| Accepts the Request Body from Smart Proxy | |
| **xWuModule** | **String**| Module of the Meta aPI | [optional] |
| **xWuPath** | **String**| Module of the Meta aPI | [optional] |

### Return type

[**CreateOrderResponse**](CreateOrderResponse.md)

### Authorization

No authorization required

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | successful operation |  * x-wu-externalRefId - The external Reference Id sent by calling application in request header. <br>  |
| **400** | Bad Request |  * x-wu-externalRefId - The external Reference Id sent by calling application in request header. <br>  |
| **500** | Internal Server Error |  * x-wu-externalRefId - The external Reference Id sent by calling application in request header. <br>  |

