package com.wu.partneros.metadata.sdk;

import com.wu.partneros.metadata.ApiClient;

import com.wu.partneros.metadata.sdk.model.CreateOrderRequestFields;
import com.wu.partneros.metadata.sdk.model.CreateOrderResponse;
import com.wu.partneros.metadata.sdk.model.WUError;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Flux;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.JavaClientCodegen", date = "2025-07-08T19:27:59.216345700-04:00[America/Toronto]", comments = "Generator version: 7.14.0")
public class CreateOrderProductMetaApi {
    private ApiClient apiClient;

    public CreateOrderProductMetaApi() {
        this(new ApiClient());
    }

    public CreateOrderProductMetaApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    
    /**
     * 
     * This API facilitates the partner to get the metadata required for the API. It provides the list of fields mandatory and optional
     * <p><b>200</b> - successful operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param body Accepts the Request Body from Smart Proxy
     * @param xWuModule Module of the Meta aPI
     * @param xWuPath Module of the Meta aPI
     * @return CreateOrderResponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    private ResponseSpec createOrderMetaRequestCreation(@javax.annotation.Nonnull CreateOrderRequestFields body, @javax.annotation.Nullable String xWuModule, @javax.annotation.Nullable String xWuPath) throws WebClientResponseException {
        Object postBody = body;
        // verify the required parameter 'body' is set
        if (body == null) {
            throw new WebClientResponseException("Missing the required parameter 'body' when calling createOrderMeta", HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null, null, null);
        }
        // create path and map variables
        final Map<String, Object> pathParams = new HashMap<String, Object>();

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();


        if (xWuModule != null)
        headerParams.add("x-wu-module", apiClient.parameterToString(xWuModule));
        if (xWuPath != null)
        headerParams.add("x-wu-path", apiClient.parameterToString(xWuPath));
        final String[] localVarAccepts = { 
            "application/json"
        };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { 
            "application/json"
        };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        String[] localVarAuthNames = new String[] {  };

        ParameterizedTypeReference<CreateOrderResponse> localVarReturnType = new ParameterizedTypeReference<CreateOrderResponse>() {};
        return apiClient.invokeAPI("/v1/partneros/meta/order/create", HttpMethod.POST, pathParams, queryParams, postBody, headerParams, cookieParams, formParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
    }

    /**
     * 
     * This API facilitates the partner to get the metadata required for the API. It provides the list of fields mandatory and optional
     * <p><b>200</b> - successful operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param body Accepts the Request Body from Smart Proxy
     * @param xWuModule Module of the Meta aPI
     * @param xWuPath Module of the Meta aPI
     * @return CreateOrderResponse
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<CreateOrderResponse> createOrderMeta(@javax.annotation.Nonnull CreateOrderRequestFields body, @javax.annotation.Nullable String xWuModule, @javax.annotation.Nullable String xWuPath) throws WebClientResponseException {
        ParameterizedTypeReference<CreateOrderResponse> localVarReturnType = new ParameterizedTypeReference<CreateOrderResponse>() {};
        return createOrderMetaRequestCreation(body, xWuModule, xWuPath).bodyToMono(localVarReturnType);
    }

    /**
     * 
     * This API facilitates the partner to get the metadata required for the API. It provides the list of fields mandatory and optional
     * <p><b>200</b> - successful operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param body Accepts the Request Body from Smart Proxy
     * @param xWuModule Module of the Meta aPI
     * @param xWuPath Module of the Meta aPI
     * @return ResponseEntity&lt;CreateOrderResponse&gt;
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public Mono<ResponseEntity<CreateOrderResponse>> createOrderMetaWithHttpInfo(@javax.annotation.Nonnull CreateOrderRequestFields body, @javax.annotation.Nullable String xWuModule, @javax.annotation.Nullable String xWuPath) throws WebClientResponseException {
        ParameterizedTypeReference<CreateOrderResponse> localVarReturnType = new ParameterizedTypeReference<CreateOrderResponse>() {};
        return createOrderMetaRequestCreation(body, xWuModule, xWuPath).toEntity(localVarReturnType);
    }

    /**
     * 
     * This API facilitates the partner to get the metadata required for the API. It provides the list of fields mandatory and optional
     * <p><b>200</b> - successful operation
     * <p><b>400</b> - Bad Request
     * <p><b>500</b> - Internal Server Error
     * @param body Accepts the Request Body from Smart Proxy
     * @param xWuModule Module of the Meta aPI
     * @param xWuPath Module of the Meta aPI
     * @return ResponseSpec
     * @throws WebClientResponseException if an error occurs while attempting to invoke the API
     */
    public ResponseSpec createOrderMetaWithResponseSpec(@javax.annotation.Nonnull CreateOrderRequestFields body, @javax.annotation.Nullable String xWuModule, @javax.annotation.Nullable String xWuPath) throws WebClientResponseException {
        return createOrderMetaRequestCreation(body, xWuModule, xWuPath);
    }
}
