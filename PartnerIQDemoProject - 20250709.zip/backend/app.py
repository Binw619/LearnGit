from flask import Flask, request, jsonify
from flask_socketio import SocketIO
from flask_cors import CORS
import subprocess
import threading
import time
import requests
import zipfile
import io
import os
import shutil
import openai
import re

app = Flask(__name__)

CORS(app)

socketio = SocketIO(app, cors_allowed_origins="*")

baseDir = "generated-artifacts"

def sync_progress(suffix, percent_point, sleep_time):
    total = 10
    percent = int(percent_point * 100 / total)
    socketio.emit("progress" + suffix, {"progress": percent, "message": f"{percent}% completed"})
    time.sleep(sleep_time)

def sync_progress_log(suffix, percent_point, log, sleep_time):
    total = 10
    percent = int(percent_point * 100 / total)
    socketio.emit("progress" + suffix, {"progress": percent, "message": f"{percent}% completed"})
    socketio.emit("log" + suffix, {"log": log})
    time.sleep(sleep_time)

def execCommand(command, cwd=None):
    print(f"\n Running: {command}")
    subprocess.run(command, shell=True, check=True, cwd=cwd)

@app.route('/list-dir', methods=['GET'])
def list_directory():
    #base_dir = os.path.abspath('.')
    root_dir = os.path.abspath(baseDir)
    requested_path = request.args.get('path', '')
    print(f"requested_path : {requested_path}")
    abs_path = os.path.abspath(os.path.join('.', requested_path))
    print(f"abs_path : {abs_path}")
    EXCLUDE_FOLDERS = {"ui_template", ".git", "__pycache__", "ui_template"}

    path = request.args.get('path', '/')
    path = os.path.abspath(path)

    #base_dir = os.path.abspath(".")
    #if not path.startswith(base_dir):
        #return jsonify({"error": "Access denied"}), 403

    if not os.path.exists(requested_path) or not os.path.isdir(requested_path):
        return jsonify({"error": "Invalid path"}), 400

    try:
        items = []
        for entry in os.scandir(requested_path):
            if entry.name.startswith("."):
                continue  # ignore hidden files
            if entry.name in EXCLUDE_FOLDERS:
                continue  # ignore exclude files
            items.append({
                "name": entry.name,
                "isDirectory": entry.is_dir()
            })

        print(f"root_dir : {root_dir}")

        # add the parent folder
        if abs_path != root_dir:
            items.insert(0, {
                "name": "..",
                "isDirectory": True
            })

        print(f"items : {items}")

        if requested_path.endswith("..") :
            index = requested_path.rfind("/") 
            print(f"index : {index}")
            if index != -1:
                index2 = requested_path.rfind("/", 0, index)
                requested_path = requested_path[:index2]

        print(f"adjusted requested_path : {requested_path}")

        return jsonify({
            "currentPath": requested_path,
            "items": items
        })
    except Exception as e:
        print(f"error : {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/create-backend-app", methods=["POST"])
def create_backend_app():
    def run_task():
        # ===== Settings =====
        project_name = "PartnerIQDemoBackendServer"
        extract_to = baseDir
        spring_initializr_url = "https://start.spring.io/starter.zip"

        params = {
            "type": "maven-project",
            "language": "java",
            "bootVersion": "3.5.0",                 # Spring Boot version
            "baseDir": project_name,                # ZIP Path
            "groupId": "com.example",
            "artifactId": project_name,
            "name": project_name,
            "packageName": "com.wu.partneriq",
            "dependencies": "web,data-jpa,security,data-mongodb,mysql"
        }

        # ===== Request Spring Initializr API =====
        sync_progress_log("_create_backend", 3, f"Requesting Spring Boot project from Spring Initializr...", 1)

        response = requests.get(spring_initializr_url, params=params)
        if response.status_code == 200:
            sync_progress_log("_create_backend", 6, f"Project package created. Download successful. Extracting...", 1)

            # UNZIP to the project path
            with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
                zip_ref.extractall(extract_to)
            
            sync_progress_log("_create_backend", 8, f"Project extracted to: {os.path.abspath(extract_to)}", 0)
        else:
            sync_progress_log("_create_backend", 10, f"Failed to download project. Status code: {response.status_code}", 0)

        # Copy template files
        source_dir = os.path.abspath("server-template")
        target_dir = os.path.abspath(baseDir + "/PartnerIQDemoBackendServer")
        shutil.copytree(source_dir, target_dir, dirs_exist_ok=True)

        log = f"Copied server template files from {source_dir} to {target_dir}"
        sync_progress_log("_create_backend", 10, log, 0)

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/create-frontend-app", methods=["POST"])
def create_frontend_app():
    def run_task():
        # ===== Settings =====
        project_name = "partneriq-demo-ui-frontend"
        target_dir = baseDir + "/"
        project_path = os.path.join(target_dir, project_name)
        dependencies = [
            "@testing-library/jest-dom@^5.17.0",
            "@testing-library/react@^13.4.0",
            "@testing-library/user-event@^13.5.0",
            "axios@^1.7.7",
            "bootstrap@^5.3.3",
            "prop-types@^15.8.1",
            "react@^18.3.1",
            "react-bootstrap@^2.10.5",
            "react-datepicker@^7.6.0",
            "react-dom@^18.3.1",
            "react-router-dom@^6.27.0",
            "react-scripts@5.0.1",
            "react-transition-group@^4.4.5",
            "web-vitals@^2.1.4",
            "wumodclient-ui@^0.1.49"
        ]

        # Step 1: create React project
        try:
            log = f"Creating a new UI project..."
            sync_progress_log("_create_frontend", 0, log, 1)

            log = f"Installing packages. This might take a couple of minutes."
            sync_progress_log("_create_frontend", 1, log, 1)

            process = subprocess.Popen(
                ["npx.cmd", "create-react-app", project_name],
                cwd=target_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                text=True,
                bufsize=1
            )
            for line in process.stdout:
                sync_progress_log("_create_frontend", 2, line, 0)

            time.sleep(1)

            log = f"Installing react, react-dom, and react-scripts with cra-template..."
            sync_progress_log("_create_frontend", 3, log, 2)

            log = f"Success! Created partneriq-demo-ui-frontend at {project_path}"
            sync_progress_log("_create_frontend", 5, log, 1)

            #exit_code = process.wait()

        except subprocess.CalledProcessError as e:
            log = f"Failed to create React app: {e}"
            sync_progress_log("_create_frontend", 10, log, 0)
            exit(1)

        # Step 2: install dependencies
        try:
            log = f"Installing template dependencies using npm..."
            sync_progress_log("_create_frontend", 7, log, 2)

            process = subprocess.Popen(
                ["npm.cmd", "install"] + dependencies,
                cwd=project_path,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                text=True,
                bufsize=1
            )
            for line in process.stdout:
                sync_progress_log("_create_frontend", 8, line, 0)

            #exit_code = process.wait()

            log = f"added 1323 packages."
            sync_progress_log("_create_frontend", 9, log, 2)

            log = f"Dependencies {dependencies} installed."
            sync_progress_log("_create_frontend", 10, log, 0)
        except subprocess.CalledProcessError as e:
            log = f"Failed to install dependencies: {e}"
            sync_progress_log("_create_frontend", 10, log, 0)
            exit(1)


    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/create-frontend-ui", methods=["POST"])
def create_frontend_UI():    
    def run_task():
        log = f"Generating PartnerIQ Demo UI..."
        sync_progress_log("_create_ui", 0, log, 1)

        log = f"Open prompt file : ui_prompt.txt"
        sync_progress_log("_create_ui", 1, log, 1)

        # call llm service to generate UI code
        client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        with open("ui_prompt.txt", "r", encoding="utf-8") as file:
            prompt_text = file.read()

        log = f"Requesting LLM service to generate UI code. This might take a couple of minutes..."
        sync_progress_log("_create_ui", 2, log, 0)

        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": prompt_text},
                {"role": "user", "content": "please start code generation"}
            ],
            temperature=0.0,
        )

        log = f"Got response from LLM service."
        sync_progress_log("_create_ui", 6, log, 1)

        reply = response.choices[0].message.content
        match = re.search(r"```jsx\n([\s\S]*?)```", reply)

        if match:
            jsx_code = match.group(1).strip()

        with open("ui_template/AnimatedRoutes.jsx", "w", encoding="utf-8") as f:
            f.write(jsx_code)

        log = f"Saved GPT response in file AnimatedRoutes.jsx"
        sync_progress_log("_create_ui", 8, log, 1)

        print("Saved GPT response in file AnimatedRoutes.jsx")

        # Copy template files
        source_dir = os.path.abspath("ui_template")
        target_dir = os.path.abspath(baseDir + "/partneriq-demo-ui-frontend/src")
        shutil.copytree(source_dir, target_dir, dirs_exist_ok=True)
        #print(f"Copied all files from {source_dir} to {target_dir}")
        #source_dir = os.path.abspath("ui_template/AnimatedRoutes.jsx")
        #target_dir = os.path.abspath("partneriq-demo-ui-frontend/src/AnimatedRoutes.jsx")
        #shutil.copyfile(source_dir, target_dir)

        log = f"Copied AnimatedRoutes.jsx file from {source_dir} to {target_dir}"
        sync_progress_log("_create_ui", 10, log, 0)

        print(f"Copied AnimatedRoutes.jsx file from {source_dir} to {target_dir}")

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/build-deploy", methods=["POST"])
def build_deploy(): 
    def run_task():
        log = f"Building PartnerIQ Demo application..."
        sync_progress_log("_build_deploy", 1, log, 2)

        log = f"PartnerIQ Demo application was built successfully."
        sync_progress_log("_build_deploy", 3, log, 2)

        log = f"Deploying PartnerIQ Demo application..."
        sync_progress_log("_build_deploy", 5, log, 2)

        log = f"PartnerIQ Demo application was deployed successfully."
        sync_progress_log("_build_deploy", 7, log, 2)

        log = f"Starting up PartnerIQ Demo application..."
        sync_progress_log("_build_deploy", 10, log, 0)

        project_path = os.path.abspath(baseDir + "/partneriq-demo-ui-frontend")
        #process = subprocess.Popen(
            #["npm", "start"],
            #cwd=project_path,
            #stdout=subprocess.PIPE,
            #stderr=subprocess.STDOUT,
            #universal_newlines=True,
            #text=True,
            #bufsize=1
        #)
        #for line in process.stdout:
            #sync_progress_log("_build_deploy", 10, line, 0)
        
        execCommand(["npm", "start"], project_path)
        #subprocess.run(["npm", "start"], cwd=project_path, check=True, shell=True)

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

##
#   PartnerOS api docs are not ready for access; only for demo purpose at now
##
@app.route("/partneros-apidocs", methods=["POST"])
def partneros_apidoc():
    def fetch_partneros_apidoc(swagger_url, output_dir, output_file, progress):
        os.makedirs(output_dir, exist_ok=True)

        try:
            log = f"Requesting api doc from url: {swagger_url}"
            sync_progress_log("_partneros_apidoc", progress, log, 1)

            #response = requests.get(swagger_url)
            #response.raise_for_status()  # Throw exception in case the status code is NOT 200

            log = f"Received api doc from PartnerOS."
            sync_progress_log("_partneros_apidoc", progress + 1, log, 1)

            file_path = os.path.join(output_dir, output_file)
            #with open(file_path, "w", encoding="utf-8") as f:
                #f.write(response.text)

            log = f"Writtern api doc in file: {file_path}"
            sync_progress_log("_partneros_apidoc", progress + 2, log, 1)

            print(f"PartnerOS api doc saved to {file_path}")

        except requests.exceptions.RequestException as e:
            log = f"Failed to request PartnerOS api doc: {e}"
            sync_progress_log("_partneros_apidoc", progress + 2, log, 1)
            print(f"Failed to download PartnerOS api doc: {e}")

    def run_task():
        catalog_api_url = "https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_workflow_v1_api/1.0.0"
        workflow_api_url = "https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_workflow_v1_api/1.0.0"
        metadata_api_url = "https://swaggerhub.corpprod.awswuintranet.net/virts/wu-partner/partnerOS_meta_v1_api/1.0.0"

        output_dir = baseDir + "/api-docs"

        fetch_partneros_apidoc(catalog_api_url, output_dir, "catalog_api-docs_spec.json", 1)
        fetch_partneros_apidoc(workflow_api_url, output_dir, "workflow_api-docs_spec.json", 4)
        fetch_partneros_apidoc(metadata_api_url, output_dir, "metadata_api-docs_spec.json", 7)

        log = f"Download PartnerOS api docs completed."
        sync_progress_log("_partneros_apidoc", 10, log, 0)

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/backend-apidocs", methods=["POST"])
def backend_apidoc():
    def fetch_backend_apidoc(swagger_url, output_dir, output_file, progress):
        os.makedirs(output_dir, exist_ok=True)

        try:
            log = f"Requesting api doc from backend: {swagger_url}"
            sync_progress_log("_backend_apidoc", progress, log, 1)

            response = requests.get(swagger_url)
            response.raise_for_status()  # Throw exception in case the status code is NOT 200

            log = f"Received api doc from backend."
            sync_progress_log("_backend_apidoc", progress + 4, log, 1)

            file_path = os.path.join(output_dir, output_file)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(response.text)

            log = f"Writtern api doc in file: {file_path}"
            sync_progress_log("_backend_apidoc", progress + 7, log, 1)

            print(f"PartnerOS api doc saved to {file_path}")

        except requests.exceptions.RequestException as e:
            log = f"Failed to request backend api doc: {e}"
            sync_progress_log("_backend_apidoc", progress + 10, log, 1)
            print(f"Failed to download backend api doc: {e}")

    def run_task():
        backend_api_url = "http://localhost:9091/v3/api-docs"
        output_dir = baseDir + "/api-docs"

        fetch_backend_apidoc(backend_api_url, output_dir, "backend_api-docs_spec.json", 1)

        log = f"Download backend api doc completed."
        sync_progress_log("_backend_apidoc", 10, log, 0)

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/partneros-sdk", methods=["POST"])
def partneros_sdk():
    def run_task():
        catalog_sdk_command = "openapi-generator-cli generate -i ./" + baseDir + "/api-docs/catalog_api-docs_spec.json -g java -o ./" + baseDir + "/sdk/catalog-sdk --library webclient --api-package com.wu.partneros.catalog.sdk --model-package com.wu.partneros.catalog.sdk.model --skip-validate-spec --auth none --additional-properties=sourceFolder=src/main/java,java8=true,dateLibrary=java8,useTags=true,interfaceOnly=false,nullable=false,generateApis=true,generateApiDocumentation=false,generateApiTests=false,generateModels=true,generateModelDocumentation=false,generateModelTests=false,generateSupportingFiles=true,useSpringBoot3=true"
        workflow_sdk_command = "openapi-generator-cli generate -i ./" + baseDir + "/api-docs/workflow_api-docs_spec.json -g java -o ./" + baseDir + "/sdk/workflow-sdk --library webclient --api-package com.wu.partneros.workflow.sdk --model-package com.wu.partneros.workflow.sdk.model --skip-validate-spec --auth none --additional-properties=sourceFolder=src/main/java,java8=true,dateLibrary=java8,useTags=true,interfaceOnly=false,nullable=false,generateApis=true,generateApiDocumentation=false,generateApiTests=false,generateModels=true,generateModelDocumentation=false,generateModelTests=false,generateSupportingFiles=true,useSpringBoot3=true"
        metadata_sdk_command = "openapi-generator-cli generate -i ./" + baseDir + "/api-docs/metadata_api-docs_spec.json -g java -o ./" + baseDir + "/sdk/metadata-sdk --library webclient --api-package com.wu.partneros.metadata.sdk --model-package com.wu.partneros.metadata.sdk.model --skip-validate-spec --auth none --additional-properties=sourceFolder=src/main/java,java8=true,dateLibrary=java8,useTags=true,interfaceOnly=false,nullable=false,generateApis=true,generateApiDocumentation=false,generateApiTests=false,generateModels=true,generateModelDocumentation=false,generateModelTests=false,generateSupportingFiles=true,useSpringBoot3=true"

        execCommand(catalog_sdk_command)
        log = f"PartnerOS Catalog SDK generated."
        sync_progress_log("_partneros_sdk", 3, log, 1)

        execCommand(workflow_sdk_command)
        log = f"PartnerOS Workflow SDK generated."
        sync_progress_log("_partneros_sdk", 6, log, 1)

        execCommand(metadata_sdk_command)
        log = f"PartnerOS Metadata SDK generated."
        sync_progress_log("_partneros_sdk", 10, log, 0)

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/backend-sdk", methods=["POST"])
def backend_sdk():
    def run_task():
        backend_sdk_command = "openapi-generator-cli generate -i ./" + baseDir + "/api-docs/backend_api-docs_spec.json -g java -o ./" + baseDir + "/sdk/backend-sdk --library webclient --api-package com.wu.partneros.backend.sdk --model-package com.wu.partneros.backend.sdk.model --skip-validate-spec --auth none --additional-properties=sourceFolder=src/main/java,java8=true,dateLibrary=java8,useTags=true,interfaceOnly=false,nullable=false,generateApis=true,generateApiDocumentation=false,generateApiTests=false,generateModels=true,generateModelDocumentation=false,generateModelTests=false,generateSupportingFiles=true,useSpringBoot3=true"
        execCommand(backend_sdk_command)
        log = f"Backend SDK generated."
        sync_progress_log("_backend_sdk", 10, log, 0)

    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

@app.route("/run-backend", methods=["POST"])
def run_backend():
    def run_task():
        project_dir = baseDir + "/PartnerIQDemoBackendServer"
        jar_name = "PartnerIqDemoBackendServerApplication-0.0.1-SNAPSHOT.jar"

        log = f"Building backend application..."
        sync_progress_log("_run_backend", 2, log, 1)
        
        command_abs_dir = os.path.abspath(os.path.join(baseDir, "PartnerIQDemoBackendServer", "mvnw.cmd"))
        #build_command = command_abs_dir + " clean package -DskipTests"
        #execCommand(build_command, project_dir)

        process = subprocess.Popen(
            [command_abs_dir, "clean", "package", "-DskipTests"],
            cwd=project_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
        for line in process.stdout:
            sync_progress_log("_run_backend", 3, line, 0)

        log = f"Packaged backend application in " + jar_name
        sync_progress_log("_run_backend", 5, log, 1)

        log = f"Starting backend application..."
        sync_progress_log("_run_backend", 7, log, 1)

        jar_path = os.path.abspath(os.path.join(project_dir, "target", jar_name))
        #run_command = "java -jar " + jar_path
        #execCommand(run_command)

        process2 = subprocess.Popen(
            ["java", "-jar", jar_path],
            cwd=project_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
        for line in process2.stdout:
            sync_progress_log("_run_backend", 10, line, 0)
        
        #log = f"Backend application started."
        #sync_progress_log("_run_backend", 10, log, 0)       
        
    threading.Thread(target=run_task).start()
    return jsonify({"status": "started"}), 200

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000)