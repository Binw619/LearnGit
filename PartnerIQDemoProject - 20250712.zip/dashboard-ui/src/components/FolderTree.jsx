import React, { useEffect, useState } from "react";
import { ListGroup } from "react-bootstrap";

const FolderTree = ({ currentPath, onNavigate }) => {
  const [folders, setFolders] = useState([]);

  useEffect(() => {
    fetch(`/api/list-dir?path=${encodeURIComponent("/")}`)
      .then((res) => res.json())
      .then((data) => {
        const onlyFolders = data.filter((item) => item.isDirectory);
        setFolders(onlyFolders);
      });
  }, []);

  return (
    <ListGroup variant="flush">
      {folders.map((folder) => (
        <ListGroup.Item
          key={folder.name}
          action
          onClick={() => onNavigate("/" + folder.name)}
        >
          📁 {folder.name}
        </ListGroup.Item>
      ))}
    </ListGroup>
  );
};

export default FolderTree;