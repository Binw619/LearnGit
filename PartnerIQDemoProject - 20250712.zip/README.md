### PartnerIQ Demo Application

* ./backend : the folder of backend server
* ./dashboard-ui : the folder of frontend dashboard ui
* ./wu-api-ui-module-upload : the folder of the uploaded ui modules
* README.md : description of the project directory and how to get start
* run_app.cmd : cmd to run the application on windows

### How to getting start and run the application

[start backend server]
* open Command Prompt and go to the path "./backend"
* set system environment variables "OPENAI_API_KEY"
* install python3 and add in system path
* run command "pip install" to install required Python libraries
* run command "python app.py" to start the backend server

[start frontend dashboard ui]
* open Command Prompt and go to the path "./dashboard-ui"
* run command "npm install" to install all required packages
* run command "set PORT=3001 && npm start" to start the frontend dashboard ui
