package com.wu.partneriq.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.partneriq.dto.RespBean;
import com.wu.partneriq.model.CreateOrderReply;
import com.wu.partneriq.model.Sender;
import com.wu.partneriq.util.FileUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;

@Service
public class CustomerKYCService {

    public ResponseEntity<Sender> getCustomerKYCById(String customerId, String firstname, String lastname) {
        try {
            String customerName = firstname + lastname;
            File file = ResourceUtils.getFile("payload/json/customer-kyc-" + customerName + "-" + customerId + ".json");
            String jsonStr = FileUtils.readFileToOneLineString(file);
            ObjectMapper mapper = new ObjectMapper();
            Sender sender = mapper.readValue(jsonStr, Sender.class);
            return ResponseEntity.ok(sender);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    public ResponseEntity<String> getKycTemplate(String countryCode) {
        try {
            File file = ResourceUtils.getFile("payload/json/kyc-template-" + countryCode + ".json");
            String jsonStr = FileUtils.readFileToOneLineString(file);
            return ResponseEntity.ok()
                    .header("Content-Type", "application/json")
                    .body(jsonStr);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.notFound().build();
        }
    }
}
