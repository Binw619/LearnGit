
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "expected_payout_amount",
    "country_iso_code",
    "currency_iso_code"
})
@Generated("jsonschema2pojo")
public class Destination {

    @JsonProperty("expected_payout_amount")
    private Integer expectedPayoutAmount;
    @JsonProperty("country_iso_code")
    private String countryIsoCode;
    @JsonProperty("currency_iso_code")
    private String currencyIsoCode;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("expected_payout_amount")
    public Integer getExpectedPayoutAmount() {
        return expectedPayoutAmount;
    }

    @JsonProperty("expected_payout_amount")
    public void setExpectedPayoutAmount(Integer expectedPayoutAmount) {
        this.expectedPayoutAmount = expectedPayoutAmount;
    }

    @JsonProperty("country_iso_code")
    public String getCountryIsoCode() {
        return countryIsoCode;
    }

    @JsonProperty("country_iso_code")
    public void setCountryIsoCode(String countryIsoCode) {
        this.countryIsoCode = countryIsoCode;
    }

    @JsonProperty("currency_iso_code")
    public String getCurrencyIsoCode() {
        return currencyIsoCode;
    }

    @JsonProperty("currency_iso_code")
    public void setCurrencyIsoCode(String currencyIsoCode) {
        this.currencyIsoCode = currencyIsoCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Destination.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("expectedPayoutAmount");
        sb.append('=');
        sb.append(((this.expectedPayoutAmount == null)?"<null>":this.expectedPayoutAmount));
        sb.append(',');
        sb.append("countryIsoCode");
        sb.append('=');
        sb.append(((this.countryIsoCode == null)?"<null>":this.countryIsoCode));
        sb.append(',');
        sb.append("currencyIsoCode");
        sb.append('=');
        sb.append(((this.currencyIsoCode == null)?"<null>":this.currencyIsoCode));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
