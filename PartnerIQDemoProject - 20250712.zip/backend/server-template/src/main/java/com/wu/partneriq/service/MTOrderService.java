package com.wu.partneriq.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.partneriq.model.*;
import com.wu.partneriq.util.FileUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;

@Service
public class MTOrderService {
    public ResponseEntity<CreateOrderReply> createOrder(CreateOrderRequest orderRequest) {
        try {
            File file = ResourceUtils.getFile("payload/json/create-order-reply.json");
            String jsonStr = FileUtils.readFileToOneLineString(file);
            ObjectMapper mapper = new ObjectMapper();
            CreateOrderReply createOrderReply = mapper.readValue(jsonStr, CreateOrderReply.class);
            return ResponseEntity.ok(createOrderReply);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    public ResponseEntity<ConfirmOrderReply> confirmOrder(ConfirmOrderRequest orderRequest) {
        try {
            File file = ResourceUtils.getFile("payload/json/confirm-order-reply.json");
            String jsonStr = FileUtils.readFileToOneLineString(file);
            ObjectMapper mapper = new ObjectMapper();
            ConfirmOrderReply confirmOrderReply = mapper.readValue(jsonStr, ConfirmOrderReply.class);
            return ResponseEntity.ok(confirmOrderReply);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    public ResponseEntity<QuoteOrderReply> quoteOrder(QuoteOrderRequest orderRequest) {
        try {
            File file = ResourceUtils.getFile("payload/json/quote-order-reply.json");
            String jsonStr = FileUtils.readFileToOneLineString(file);
            ObjectMapper mapper = new ObjectMapper();
            QuoteOrderReply quoteOrderReply = mapper.readValue(jsonStr, QuoteOrderReply.class);
            return ResponseEntity.ok(quoteOrderReply);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }
}
