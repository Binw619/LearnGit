import { Card, Col, FloatingLabel, Form, Row, InputGroup, DropdownButton, Dropdown, Button } from "react-bootstrap";
import { NameType } from "../constants/NameType";
import { useState, useEffect } from 'react';
import React, { Component } from 'react';

const TxnReviewModule = () => {

    return (
        <div>
            <Card style={{ width: '100%', marginTop: '10px' }}>
                <Card.Body>
                    <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                        Review your transaction before submission
                    </Card.Title>
                    <Form>
                        <Row>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%',marginTop: '20px', fontWeight: 'bold' }}>Send to </Form.Label>
                            </Col>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%',marginTop: '20px' }}>United States</Form.Label>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%',marginTop: '20px', fontWeight: 'bold' }}>Amount to send </Form.Label>
                            </Col>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%',marginTop: '20px' }}>5000.00 PHP</Form.Label>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%',marginTop: '20px', fontWeight: 'bold' }}>Amount to receive </Form.Label>
                            </Col>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%',marginTop: '20px' }}>87.39 USD</Form.Label>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%',marginTop: '20px', fontWeight: 'bold' }}>Our fees </Form.Label>
                            </Col>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%',marginTop: '20px' }}>150.00 PHP</Form.Label>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%',marginTop: '20px', fontWeight: 'bold' }}>Total you pay </Form.Label>
                            </Col>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%',marginTop: '20px' }}>5150.00 PHP</Form.Label>
                            </Col>
                        </Row>
                    </Form>
                </Card.Body>
            </Card>
        </div>
    );
}

export default TxnReviewModule;
