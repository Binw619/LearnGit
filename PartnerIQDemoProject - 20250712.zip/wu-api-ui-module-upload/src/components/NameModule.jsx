import React, { Component } from 'react';
import { Card, Col, FloatingLabel, Form, FormLabel, Row } from "react-bootstrap";
import { NameType } from "../constants/NameType";
import { useState } from 'react';

const NameModule = ({ title, type }) => {

    const [nameType, setNameType] = useState(type);

    const changeNameType = (event) => {
        const newNameType = event.target.value;
        setNameType(newNameType);
    };

    return (
        <div>
            <Card style={{ width: '100%', marginTop: '10px' }}>
                <Card.Body>
                    <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                        Name of {title}
                    </Card.Title>
                    {
                        nameType === NameType.TypeD ? (
                            <Form>
                                <Row>
                                    <Col sm={2}>
                                        <Form style={{ marginTop: '10px' }}>
                                            <Form.Group className="mb-2" controlId="nameType">
                                                <Form.Select aria-label="Type of name" size='sm' value={nameType} onChange={changeNameType}>
                                                    <option value={NameType.TypeD}>Name type {NameType.TypeD}</option>
                                                    <option value={NameType.TypeM}>Name type {NameType.TypeM}</option>
                                                </Form.Select>
                                            </Form.Group>
                                        </Form>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col>
                                        <FloatingLabel
                                            controlId="firstName"
                                            label="First Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="middleName"
                                            label="Middle Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="lastName"
                                            label="Last Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                </Row>
                            </Form>
                        ) : (
                            <Form>
                                <Row>
                                    <Col sm={2}>
                                        <Form style={{ marginTop: '10px' }}>
                                            <Form.Group className="mb-2" controlId="nameType">
                                                <Form.Select aria-label="Type of name" size='sm' value={nameType} onChange={changeNameType}>
                                                    <option value={NameType.TypeD}>Name type {NameType.TypeD}</option>
                                                    <option value={NameType.TypeM}>Name type {NameType.TypeM}</option>
                                                </Form.Select>
                                            </Form.Group>
                                        </Form>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col>
                                        <FloatingLabel
                                            controlId="givenName"
                                            label="Given Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="paternalName"
                                            label="Paternal Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="maternalName"
                                            label="Maternal Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                </Row>
                            </Form>
                        )
                    }
                </Card.Body>
            </Card>
        </div>
    );
}

export default NameModule;
