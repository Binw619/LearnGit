import { Card, Col, FloatingLabel, Form, FormLabel, Row } from "react-bootstrap";
import { NameType } from "../constants/NameType";
import { useState } from 'react';
import React, { Component } from 'react';

const AddressModule = () => {

    return (
        <div>
            <Card style={{ width: '100%', marginTop: '10px' }}>
                <Card.Body>
                    <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                        Address info
                    </Card.Title>
                    <Form>
                        <Row>
                            <Col sm={6}>
                                <FloatingLabel
                                    controlId="addressLine1"
                                    label="Address line 1"
                                    className="mb-3"
                                >
                                    <Form.Control type="input" placeholder=""
                                        defaultValue="    "
                                    />
                                </FloatingLabel>
                            </Col>
                            <Col sm={6}>
                                <FloatingLabel
                                    controlId="addressLine2"
                                    label="Address line 2"
                                    className="mb-3"
                                >
                                    <Form.Control type="input" placeholder=""
                                        defaultValue="    "
                                    />
                                </FloatingLabel>
                            </Col>
                        </Row>
                        <Row>
                            <Col>
                                <FloatingLabel
                                    controlId="city"
                                    label="City"
                                    className="mb-3"
                                >
                                    <Form.Control type="input" placeholder=""
                                        defaultValue="    "
                                    />
                                </FloatingLabel>
                            </Col>
                            <Col>
                                <FloatingLabel
                                    controlId="state"
                                    label="State"
                                    className="mb-3"
                                >
                                    <Form.Control type="input" placeholder=""
                                        defaultValue="    "
                                    />
                                </FloatingLabel>
                            </Col>
                            <Col>
                                <FloatingLabel
                                    controlId="postalCode"
                                    label="Postal code"
                                    className="mb-3"
                                >
                                    <Form.Control type="input" placeholder=""
                                        defaultValue="    "
                                    />
                                </FloatingLabel>
                            </Col>
                        </Row>
                    </Form>
                </Card.Body>
            </Card>
        </div>
    );
}

export default AddressModule;
