import { Card, Col, FloatingLabel, Form, FormLabel, Row, Button } from "react-bootstrap";
import { useState } from 'react';
import React, { Component } from 'react';

const SignupModule = () => {

    return (
        <div>
            <Card style={{ width: '100%', marginTop: '10px' }}>
                <Card.Body>
                    <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                        Create your profile
                    </Card.Title>
                    <Form>
                        <Row>
                            <Col sm={12}>
                                <FloatingLabel
                                    controlId="useraccount"
                                    label="Email or mobile number"
                                    className="mb-3"
                                >
                                    <Form.Control type="input" placeholder=""
                                        defaultValue="    "
                                    />
                                </FloatingLabel>
                            </Col>
                            </Row>
                        <Row>
                            <Col sm={12}>
                                <FloatingLabel
                                    controlId="password"
                                    label="Create your password"
                                    className="mb-3"
                                >
                                    <Form.Control type="password" placeholder=""
                                        defaultValue="    "
                                    />
                                </FloatingLabel>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={12}>
                                <Form.Label className="text-start">By submitting this form, I agree to the Privacy Statement, Western Union Terms and Conditions and agree WU may contact me and send me marketing communications using the contact details I have provided.</Form.Label>
                            </Col>
                            </Row>
                        <Row>
                            <Col sm={12}>
                                <Button style={{ width: '100%', marginTop: '20px', backgroundColor: 'yellow', color: 'black', border: 'none', fontWeight: 'bold' }} ><a href="/senderdetails">Register</a></Button>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={12}>
                                <Form.Label style={{ width: '100%',marginTop: '20px', fontWeight: 'bold' }}>Already registered? <a href="/mylogin">Login</a></Form.Label>
                            </Col>
                        </Row>
                    </Form>
                </Card.Body>
            </Card>
        </div>
    );
}

export default SignupModule;
