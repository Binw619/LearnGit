import React, { Component } from 'react';
import { useState, useEffect } from 'react';
import { Card, Col, Container, FloatingLabel, Form, Row } from "react-bootstrap";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

let dictionary = {};
let defaultValue = '';

const KYCTemplateModule = (props) => {
    const [templateFields, setTemplateFields] = useState(new Array());
    dictionary["id_issue_date"] = new Date();
    dictionary["id_expiration_date"] = new Date();
    dictionary["date_of_birth"] = new Date();

    const [issueDate, setIssueDate] = useState(new Date());
    const [expireDate, setExpireDate] = useState(new Date());

    const requestTemplate = async (countryCode, setTemplateFields) => {
        let url = 'http://localhost:9091/customer/kyc/template?countryCode=' + countryCode
        await fetch(url, {
            method: 'GET',
            headers: {
                'Content-type': 'application/json; charset=UTF-8',
            },
        })
            .then((response) => response.json())
            .then((data) => {
                console.log("data.templateFields", data.templateFields);
                setTemplateFields(data.templateFields);
            })
            .catch((err) => {
                console.log(err.message);
            });
    };

    useEffect(() => {
        const defaultCountryCode = props.countryCode || 'PH';
        requestTemplate(defaultCountryCode, setTemplateFields);
    }, [props.countryCode]);


    function RenderDropdown(props) {
        const dropdown = props.dropdown;
        let content = [];
        let n = dropdown.length;
        for (let i = 0; i < n; i++) {
            const option = dropdown[i];
            if (option.defaultOption === true) {
                content.push(
                    <option key={option.text} value={option.value} selected>{option.text}</option>
                );
            } else {
                content.push(
                    <option key={option.text} value={option.value}>{option.text}</option>
                );
            }
        }
        return content;
    }

    function RenderTemplateFields() {
        let content = [];
        let n = templateFields.length;
        let subcontent = [];
        let count = 0;
        for (let i = 0; i < n; i++) {
            const field = templateFields[i];
            console.log("my field.fieldName : ", field.fieldName);
            defaultValue = "     ";

            if (field.fieldType === 'DROPDOWN') {
                if (field.fieldName === 'gender' ||
                    field.fieldName === 'id_type' ||
                    field.fieldName === 'id_country_of_issue' ||
                    field.fieldName === 'occupation' ||
                    field.fieldName === 'transaction_reason' ||
                    field.fieldName === 'country_of_birth' ||
                    field.fieldName === 'nationality' ||
                    field.fieldName === 'source_of_funds' ||
                    field.fieldName === 'relationship_to_receiver_sender') {
                    const dropdownOptions = field.dropdown;
                    const m = dropdownOptions.length;
                    subcontent.push(
                        <Col sm={4}>
                            <Form.Group className="mb-2" controlId={field.fieldName} key={field.fieldName}>
                                <FloatingLabel
                                    controlId={field.fieldName}
                                    label={'[' + field.fieldText + ']'}
                                    className="mb-3"
                                >
                                    <select className="form-select form-select-sm" aria-label=".form-select-sm example">
                                        <RenderDropdown dropdown={dropdownOptions} />
                                    </select>
                                </FloatingLabel>
                            </Form.Group>
                        </Col>
                    );
                } else {
                    subcontent.push(
                        <Col sm={4}>
                            <Form.Group className="mb-2" controlId={field.fieldName} key={field.fieldName}>
                                <FloatingLabel
                                    controlId={field.fieldName}
                                    label={'[' + field.fieldText + ']'}
                                    className="mb-3"
                                >
                                    <select className="form-select form-select-sm" aria-label=".form-select-sm example">
                                        <option key="1" value="1">One</option>
                                        <option key="2" value="2">Two</option>
                                        <option key="3" value="3">Three</option>
                                    </select>
                                </FloatingLabel>
                            </Form.Group>
                        </Col>
                    );
                }
                count++;
            } else if (field.fieldType === 'DATE') {
                console.log("field.fieldType !!! ", field.fieldType);
                subcontent.push(
                    <Col sm={4}>
                        <Row>
                            <Col>
                                <label style={{ marginLeft: "14px", marginBottom: "5px", fontSize: "14px", color: 'gray', display: 'flex', justifyContent: "start" }}>{'[' + field.fieldText + ']'}</label>
                            </Col>
                        </Row>
                        <Row>
                            <Col style={{ marginLeft: "14px", fontSize: "14px", marginBottom: "15px", display: 'flex', justifyContent: "start", zIndex: 11 }}>
                                <DatePicker
                                    ariaLabelClose="aaa"
                                    selected={dictionary[field.fieldName]}
                                    //onSelect={handleDateSelect} //when day is clicked
                                    onChange={(date) => { dictionary[field.fieldName] = date; }} //only when value has changed
                                />
                            </Col>
                        </Row>
                    </Col>
                );
                count++;
            } else if (field.fieldName !== 'template_id' && field.fieldName !== 'version') {
                subcontent.push(
                    <Col sm={4}>
                        <Form.Group className="mb-2" controlId={field.fieldName} key={field.fieldName}>
                            <FloatingLabel
                                controlId={field.fieldName}
                                label={'[' + field.fieldText + ']'}
                                className="mb-3"
                            >
                                <Form.Control type="input" placeholder={field.fieldText} onChange={changeFieldValue}
                                    defaultValue={defaultValue}
                                />
                            </FloatingLabel>
                        </Form.Group>
                    </Col>
                );
                count++;
            }

            if (count === 3) {
                content.push(
                    <Row>
                        {subcontent}
                    </Row>
                );
                subcontent = [];
                count = 0;
            }
        }
        if (count !== 0) {
            content.push(
                <Row>
                    {subcontent}
                </Row>
            );
        }
        return content;
    }

    const changeFieldValue = (event) => {
        //console.log("event.target id ", event.target.id);
        const fieldId = event.target.id;
        const value = event.target.value;
        dictionary[fieldId] = value;
    }



    return (
        <div>
            <Card style={{ width: '100%', marginTop: '10px' }}>
                <Card.Body>
                    <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                        KYC details
                    </Card.Title>
                    <Form>
                        <Row>
                            <Col>
                                <div id="show-sender-details-window">
                                    <RenderTemplateFields />
                                </div>
                            </Col>
                        </Row>
                    </Form>
                </Card.Body>
            </Card>
        </div >
    );
}

export default KYCTemplateModule;