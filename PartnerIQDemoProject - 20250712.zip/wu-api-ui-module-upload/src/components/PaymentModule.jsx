import { Card, Col, FloatingLabel, Form, Row, InputGroup, DropdownButton, Dropdown, Button } from "react-bootstrap";
import { useState, useEffect } from 'react';
import React, { Component } from 'react';
import transferImg from "../img/transfer.png";
import arrowright from "../img/arrowright.png";

const PaymentModule = (props) => {

    const sendAmountLabelPrefix = "Send amount";
    const receiveAmountLabelPrefix = "Receive amount";
    const sendingCountryCode = props.countrycode
    const sendingCurrencyCode = props.currencycode;
    const [ccList, setCcList] = useState(new Array());
    const [sendAmount, setSendAmount] = useState('5000.00');
    const [receiveAmount, setReceiveAmount] = useState('87.39');
    const [destinationCurrency, setDestinationCurrency] = useState({
        receiveCurrencyCode: '',
        selectedCcOption: ''
    });

    useEffect(() => {
        if (ccList && ccList[0] !== undefined) {
            setDestinationCurrency({
                receiveCurrencyCode: ccList[0].value,
                selectedCcOption: ccList[0].text
            });
        }
    }, [ccList]);

    const requestCcList = async (setCcList) => {
        let url = 'http://localhost:9091/metadata/cclist';
        await fetch(url, {
            method: 'GET',
            headers: {
                'Content-type': 'application/json; charset=UTF-8',
            },
        })
            .then((response) => response.json())
            .then((data) => {
                console.log("data.cclist", data.cclist);
                setCcList(data.cclist);
            })
            .catch((err) => {
                console.log(err.message);
            });
    };

    useEffect(() => {
        requestCcList(setCcList);
    }, []);

    function RenderDropdown(props) {
        const dropdown = props.dropdown;
        let content = [];
        let n = dropdown.length;
        let selectedCc = destinationCurrency.selectedCcOption;
        if(selectedCc === '' && dropdown[0] !== undefined) {
            console.log("dropdown[0]", dropdown[0]);
            selectedCc = dropdown[0].text;
        }
        for (let i = 0; i < n; i++) {
            const option = dropdown[i];
            if(selectedCc === option.text) {
                content.push(<option key={option.text} value={option.value} selected>{option.text}</option>);
            } else {
                content.push(<option key={option.text} value={option.value}>{option.text}</option>);
            }
        }
        return content;
    }

    const changeDestination = (event) => {
        const targetId = event.target.id;
        const selectedOption = event.target.options[event.target.selectedIndex].text;
        const cc = event.target.value;
        setDestinationCurrency({
            receiveCurrencyCode: cc,
            selectedCcOption: selectedOption
        });
    }

    return (
        <div>
            <Card style={{ width: '100%', marginTop: '10px' }}>
                <Card.Body>
                    <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                        Send money now
                    </Card.Title>
                    <Form>
                        <Row>
                            <Col sm={3}>
                                <Form.Group className="mb-2" controlId="destination" style={{marginTop: "10px"}}>
                                    <FloatingLabel
                                        controlId="destination"
                                        label="Send to"
                                        className="mb-3"
                                    >
                                        <Form.Select aria-label="Select a country" size='sm' onChange={changeDestination}>
                                            <RenderDropdown dropdown={ccList} />
                                        </Form.Select>
                                    </FloatingLabel>
                                </Form.Group>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={3}>
                                <Form.Group className="mb-2" controlId="sendamount">
                                    <Form.Label className="mb-3" style={{ marginLeft: "0", marginBottom: "0", fontSize: "15px", color: 'black', display: 'flex', justifyContent: "start" }}>Amount to send</Form.Label>
                                    <InputGroup style={{ marginTop: "0", paddingTop: "0" }}>
                                        <Form.Control type="text" placeholder="" defaultValue={sendAmount} />
                                        <DropdownButton
                                            variant="outline-secondary"
                                            title={sendingCurrencyCode}
                                            id="input-group-dropdown"
                                            align="end"
                                        >
                                            <Dropdown.Item>{sendingCurrencyCode}</Dropdown.Item>
                                        </DropdownButton>
                                    </InputGroup>
                                </Form.Group>
                            </Col>
                            <Col sm={1}>
                                <img src={transferImg} style={{ width: "20px", height: "20px", marginTop: "20px", marginTop: "45px" }}></img>
                            </Col>
                            <Col sm={3}>
                                <Form.Group className="mb-2" controlId="receiveamount">
                                    <Form.Label className="mb-3" style={{ marginLeft: "0", marginBottom: "0", fontSize: "15px", color: 'black', display: 'flex', justifyContent: "start" }}>Amount to receive</Form.Label>
                                    <InputGroup style={{ marginTop: "0", paddingTop: "0" }}>
                                        <Form.Control type="input" placeholder="" defaultValue={receiveAmount} />
                                        <DropdownButton
                                            variant="outline-secondary"
                                            title={destinationCurrency.receiveCurrencyCode}
                                            id="input-group-dropdown"
                                            align="end"
                                        >
                                            <Dropdown.Item>{destinationCurrency.receiveCurrencyCode}</Dropdown.Item>
                                        </DropdownButton>
                                    </InputGroup>
                                </Form.Group>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={3}>
                                <Form.Group className="mb-2" controlId="receiveamount" style={{ marginTop: "10px"}}>
                                    <Form.Label className="mb-3" style={{ marginLeft: "0", marginBottom: "0", fontSize: "15px", color: 'black', display: 'flex', justifyContent: "start" }}>Fees - Delivery in minutes</Form.Label>
                                    <InputGroup style={{ marginTop: "0", paddingTop: "0" }}>
                                        <Form.Control type="text" placeholder="" defaultValue="150.00" />
                                        <DropdownButton
                                            variant="outline-secondary"
                                            title={sendingCurrencyCode}
                                            id="input-group-dropdown"
                                            align="end"
                                        >
                                            <Dropdown.Item>{sendingCurrencyCode}</Dropdown.Item>
                                        </DropdownButton>
                                    </InputGroup>
                                </Form.Group>
                            </Col>
                            <Col sm={1}>
                                <img src={arrowright} style={{ width: "20px", height: "20px", marginTop: "55px"}}></img>
                            </Col>
                            <Col sm={3}>
                                <Form.Group className="mb-2" controlId="receiveamount" style={{ marginTop: "10px"}}>
                                    <Form.Label className="mb-3" style={{ marginLeft: "0", marginBottom: "0", fontSize: "15px", fontWeight: 'bold', color: 'black', display: 'flex', justifyContent: "start" }}>Total you pay</Form.Label>
                                    <InputGroup style={{ marginTop: "0", paddingTop: "0" }}>
                                        <Form.Control type="text" placeholder="" defaultValue="5150.00" />
                                        <DropdownButton
                                            variant="outline-secondary"
                                            title={sendingCurrencyCode}
                                            id="input-group-dropdown"
                                            align="end"
                                        >
                                            <Dropdown.Item>{sendingCurrencyCode}</Dropdown.Item>
                                        </DropdownButton>
                                    </InputGroup>
                                </Form.Group>
                            </Col>
                        </Row>
                    </Form>
                </Card.Body>
            </Card>
        </div>
    );
}

export default PaymentModule;
