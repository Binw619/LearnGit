import { Card, Col, FloatingLabel, Form, FormLabel, Row, Button } from "react-bootstrap";
import { NameType } from "../constants/NameType";
import { useState } from 'react';
import React, { Component } from 'react';

const LoginModule = () => {
    return (
        <div>
            <Card style={{ width: '100%', marginTop: '10px' }}>
                <Card.Body>
                    <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                        Welcome back!
                    </Card.Title>
                    <Form>
                        <Row>
                            <Col sm={12}>
                                <FloatingLabel
                                    controlId="useraccount"
                                    label="Email or mobile number"
                                    className="mb-3"
                                >
                                    <Form.Control type="input" placeholder=""
                                        defaultValue="    "
                                    />
                                </FloatingLabel>
                            </Col>
                            </Row>
                        <Row>
                            <Col sm={12}>
                                <FloatingLabel
                                    controlId="password"
                                    label="Password"
                                    className="mb-3"
                                >
                                    <Form.Control type="password" placeholder=""
                                        defaultValue="    "
                                    />
                                </FloatingLabel>
                            </Col>
                        </Row>
                                                <Row>
                            <Col sm={12} className="mt-3 d-flex justify-content-end">
                                <Form.Label><a href="/signup">Forgot your password?</a></Form.Label>
                            </Col>
                            </Row>
                        <Row>
                            <Col sm={12}>
                                <Button style={{ width: '100%', marginTop: '20px', backgroundColor: 'yellow', color: 'black', border: 'none', fontWeight: 'bold' }} ><a href="/">Login</a></Button>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={12}>
                                <Button style={{ width: '100%',marginTop: '20px', backgroundColor: 'white', color: 'black', border: '1px solid', fontWeight: 'bold' }}>Login with OTP</Button>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={12}>
                                <Form.Label style={{ width: '100%',marginTop: '20px', fontWeight: 'bold' }}>New to Western Union? <a href="/signup">Sign up</a></Form.Label>
                            </Col>
                        </Row>
                    </Form>
                </Card.Body>
            </Card>
        </div>
    );
}

export default LoginModule;
