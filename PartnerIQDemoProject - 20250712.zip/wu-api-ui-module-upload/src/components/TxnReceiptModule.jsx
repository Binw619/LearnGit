import { Card, Col, FloatingLabel, Form, Row, InputGroup, DropdownButton, Dropdown, Button } from "react-bootstrap";
import { NameType } from "../constants/NameType";
import { useState, useEffect } from 'react';
import React, { Component } from 'react';

const TxnReceiptModule = () => {

    return (
        <div>
            <Card style={{ width: '100%', marginTop: '10px' }}>
                <Card.Body>
                    <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                        Thanks you! You've completed your transaction.
                    </Card.Title>
                    <Form>
                        <Row>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%', marginTop: '20px', fontWeight: 'bold' }}>Track number </Form.Label>
                            </Col>
                            <Col sm={6}>
                                <Form.Label className="text-start text-decoration-underline" style={{ width: '50%', marginTop: '20px', fontWeight: 'bold', fontSize: '18px' }}>0 1 2 - 3 4 5 - 6 7 8 9</Form.Label>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%', marginTop: '20px', fontWeight: 'bold' }}>Send to </Form.Label>
                            </Col>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%', marginTop: '20px' }}>United States</Form.Label>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%', marginTop: '20px', fontWeight: 'bold' }}>Amount to send </Form.Label>
                            </Col>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%', marginTop: '20px' }}>5000.00 PHP</Form.Label>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%', marginTop: '20px', fontWeight: 'bold' }}>Amount to receive </Form.Label>
                            </Col>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%', marginTop: '20px' }}>87.39 USD</Form.Label>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%', marginTop: '20px', fontWeight: 'bold' }}>Our fees </Form.Label>
                            </Col>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%', marginTop: '20px' }}>150.00 PHP</Form.Label>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%', marginTop: '20px', fontWeight: 'bold' }}>Total you pay </Form.Label>
                            </Col>
                            <Col sm={2}>
                                <Form.Label className="text-start" style={{ width: '100%', marginTop: '20px' }}>5150.00 PHP</Form.Label>
                            </Col>
                        </Row>
                        <Row>
                            <Col sm={12}>
                                <Button style={{ width: '100%', marginTop: '20px', backgroundColor: 'yellow', color: 'black', border: 'none', fontWeight: 'bold' }}>Track your transaction</Button>
                            </Col>
                        </Row>
                    </Form>
                </Card.Body>
            </Card>
        </div>
    );
}

export default TxnReceiptModule;
