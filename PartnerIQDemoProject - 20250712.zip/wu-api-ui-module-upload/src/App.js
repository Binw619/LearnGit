import { useState, useEffect } from 'react';
import DynamicTemplate from "./components/DynamicTemplate";
import React, { createContext } from "react";
import TemplateService from "./services/TemplateService";

function WUApiUI() {
  const [ccList, setCcList] = useState(new Array());

  useEffect(() => {
    TemplateService.getCountryCurrencyList().then(resp => {
      setCcList(resp.data.obj);
    });
  }, []);

  return (
    <DynamicTemplate ccList={ccList} />
  );
}

export default WUApiUI;
