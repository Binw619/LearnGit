export const NameType = Object.freeze({
  TypeD: 'D',
  TypeM: 'M',
});