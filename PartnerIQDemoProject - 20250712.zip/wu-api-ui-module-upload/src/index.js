import React from 'react';
import ReactDOM from 'react-dom/client';


export { default as WUApiUI } from './App';
export { default as NameModule } from './components/NameModule';
export { default as AddressModule} from './components/AddressModule';
export { default as KYCTemplateModule } from './components/KYCTemplateModule';
export { default as PaymentModule } from './components/PaymentModule';
export { default as LoginModule } from './components/LoginModule';
export { default as SignupModule } from './components/SignupModule';
export { default as TxnReceiptModule } from './components/TxnReceiptModule';
export { default as TxnReviewModule } from './components/TxnReviewModule';
export { NameType } from './constants/NameType';