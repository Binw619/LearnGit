package com.wu.partneriq.controller;

import com.wu.partneriq.model.QuoteOrderReply;
import com.wu.partneriq.model.Sender;
import com.wu.partneriq.service.CustomerKYCService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customer")
public class CustomerKYCController {
    @Autowired
    CustomerKYCService customerKYCService;

    @GetMapping(path = "/kyc")
    public ResponseEntity<Sender> getCustomerKYCById(@RequestParam(name = "customerId") String customerId,
                                                     @RequestParam(name = "firstname") String firstname,
                                                     @RequestParam(name = "lastname")String lastname) {
        return customerKYCService.getCustomerKYCById(customerId, firstname, lastname);
    }
}
