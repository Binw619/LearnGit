
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "id_number",
    "id_country_of_issue",
    "id_type"
})
@Generated("jsonschema2pojo")
public class IdDetails {

    @JsonProperty("id_number")
    private String idNumber;
    @JsonProperty("id_country_of_issue")
    private String idCountryOfIssue;
    @JsonProperty("id_type")
    private String idType;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("id_number")
    public String getIdNumber() {
        return idNumber;
    }

    @JsonProperty("id_number")
    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    @JsonProperty("id_country_of_issue")
    public String getIdCountryOfIssue() {
        return idCountryOfIssue;
    }

    @JsonProperty("id_country_of_issue")
    public void setIdCountryOfIssue(String idCountryOfIssue) {
        this.idCountryOfIssue = idCountryOfIssue;
    }

    @JsonProperty("id_type")
    public String getIdType() {
        return idType;
    }

    @JsonProperty("id_type")
    public void setIdType(String idType) {
        this.idType = idType;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(IdDetails.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("idNumber");
        sb.append('=');
        sb.append(((this.idNumber == null)?"<null>":this.idNumber));
        sb.append(',');
        sb.append("idCountryOfIssue");
        sb.append('=');
        sb.append(((this.idCountryOfIssue == null)?"<null>":this.idCountryOfIssue));
        sb.append(',');
        sb.append("idType");
        sb.append('=');
        sb.append(((this.idType == null)?"<null>":this.idType));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
