package com.wu.partneriq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PartnerIQServerDemoApplication {
    public static void main(String... args) {
        SpringApplication.run(PartnerIQServerDemoApplication.class, args);
    }
}
