
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "date_of_birth",
    "Does_the_ID_have_an_expiration_date",
    "template_id",
    "Country_of_Birth",
    "id_details",
    "id_expiration_date",
    "ack_flag"
})
@Generated("jsonschema2pojo")
public class ComplianceDetails {

    @JsonProperty("date_of_birth")
    private Integer dateOfBirth;
    @JsonProperty("Does_the_ID_have_an_expiration_date")
    private String doesTheIDHaveAnExpirationDate;
    @JsonProperty("template_id")
    private String templateId;
    @JsonProperty("Country_of_Birth")
    private String countryOfBirth;
    @JsonProperty("id_details")
    @Valid
    private IdDetails idDetails;
    @JsonProperty("id_expiration_date")
    private String idExpirationDate;
    @JsonProperty("ack_flag")
    private String ackFlag;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("date_of_birth")
    public Integer getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("date_of_birth")
    public void setDateOfBirth(Integer dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @JsonProperty("Does_the_ID_have_an_expiration_date")
    public String getDoesTheIDHaveAnExpirationDate() {
        return doesTheIDHaveAnExpirationDate;
    }

    @JsonProperty("Does_the_ID_have_an_expiration_date")
    public void setDoesTheIDHaveAnExpirationDate(String doesTheIDHaveAnExpirationDate) {
        this.doesTheIDHaveAnExpirationDate = doesTheIDHaveAnExpirationDate;
    }

    @JsonProperty("template_id")
    public String getTemplateId() {
        return templateId;
    }

    @JsonProperty("template_id")
    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    @JsonProperty("Country_of_Birth")
    public String getCountryOfBirth() {
        return countryOfBirth;
    }

    @JsonProperty("Country_of_Birth")
    public void setCountryOfBirth(String countryOfBirth) {
        this.countryOfBirth = countryOfBirth;
    }

    @JsonProperty("id_details")
    public IdDetails getIdDetails() {
        return idDetails;
    }

    @JsonProperty("id_details")
    public void setIdDetails(IdDetails idDetails) {
        this.idDetails = idDetails;
    }

    @JsonProperty("id_expiration_date")
    public String getIdExpirationDate() {
        return idExpirationDate;
    }

    @JsonProperty("id_expiration_date")
    public void setIdExpirationDate(String idExpirationDate) {
        this.idExpirationDate = idExpirationDate;
    }

    @JsonProperty("ack_flag")
    public String getAckFlag() {
        return ackFlag;
    }

    @JsonProperty("ack_flag")
    public void setAckFlag(String ackFlag) {
        this.ackFlag = ackFlag;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ComplianceDetails.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("dateOfBirth");
        sb.append('=');
        sb.append(((this.dateOfBirth == null)?"<null>":this.dateOfBirth));
        sb.append(',');
        sb.append("doesTheIDHaveAnExpirationDate");
        sb.append('=');
        sb.append(((this.doesTheIDHaveAnExpirationDate == null)?"<null>":this.doesTheIDHaveAnExpirationDate));
        sb.append(',');
        sb.append("templateId");
        sb.append('=');
        sb.append(((this.templateId == null)?"<null>":this.templateId));
        sb.append(',');
        sb.append("countryOfBirth");
        sb.append('=');
        sb.append(((this.countryOfBirth == null)?"<null>":this.countryOfBirth));
        sb.append(',');
        sb.append("idDetails");
        sb.append('=');
        sb.append(((this.idDetails == null)?"<null>":this.idDetails));
        sb.append(',');
        sb.append("idExpirationDate");
        sb.append('=');
        sb.append(((this.idExpirationDate == null)?"<null>":this.idExpirationDate));
        sb.append(',');
        sb.append("ackFlag");
        sb.append('=');
        sb.append(((this.ackFlag == null)?"<null>":this.ackFlag));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
