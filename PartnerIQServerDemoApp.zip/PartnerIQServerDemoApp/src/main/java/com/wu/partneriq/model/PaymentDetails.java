
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "message_charges",
    "fees",
    "exchange_rate",
    "origination",
    "payment_digest",
    "destination",
    "taxes",
    "promotion"
})
@Generated("jsonschema2pojo")
public class PaymentDetails {

    @JsonProperty("message_charges")
    private String messageCharges;
    @JsonProperty("fees")
    @Valid
    private Fees fees;
    @JsonProperty("exchange_rate")
    private Double exchangeRate;
    @JsonProperty("origination")
    @Valid
    private Origination origination;
    @JsonProperty("payment_digest")
    private String paymentDigest;
    @JsonProperty("destination")
    @Valid
    private Destination destination;
    @JsonProperty("taxes")
    @Valid
    private Taxes taxes;
    @JsonProperty("promotion")
    @Valid
    private Promotion promotion;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("message_charges")
    public String getMessageCharges() {
        return messageCharges;
    }

    @JsonProperty("message_charges")
    public void setMessageCharges(String messageCharges) {
        this.messageCharges = messageCharges;
    }

    @JsonProperty("fees")
    public Fees getFees() {
        return fees;
    }

    @JsonProperty("fees")
    public void setFees(Fees fees) {
        this.fees = fees;
    }

    @JsonProperty("exchange_rate")
    public Double getExchangeRate() {
        return exchangeRate;
    }

    @JsonProperty("exchange_rate")
    public void setExchangeRate(Double exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    @JsonProperty("origination")
    public Origination getOrigination() {
        return origination;
    }

    @JsonProperty("origination")
    public void setOrigination(Origination origination) {
        this.origination = origination;
    }

    @JsonProperty("payment_digest")
    public String getPaymentDigest() {
        return paymentDigest;
    }

    @JsonProperty("payment_digest")
    public void setPaymentDigest(String paymentDigest) {
        this.paymentDigest = paymentDigest;
    }

    @JsonProperty("destination")
    public Destination getDestination() {
        return destination;
    }

    @JsonProperty("destination")
    public void setDestination(Destination destination) {
        this.destination = destination;
    }

    @JsonProperty("taxes")
    public Taxes getTaxes() {
        return taxes;
    }

    @JsonProperty("taxes")
    public void setTaxes(Taxes taxes) {
        this.taxes = taxes;
    }

    @JsonProperty("promotion")
    public Promotion getPromotion() {
        return promotion;
    }

    @JsonProperty("promotion")
    public void setPromotion(Promotion promotion) {
        this.promotion = promotion;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(PaymentDetails.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("messageCharges");
        sb.append('=');
        sb.append(((this.messageCharges == null)?"<null>":this.messageCharges));
        sb.append(',');
        sb.append("fees");
        sb.append('=');
        sb.append(((this.fees == null)?"<null>":this.fees));
        sb.append(',');
        sb.append("exchangeRate");
        sb.append('=');
        sb.append(((this.exchangeRate == null)?"<null>":this.exchangeRate));
        sb.append(',');
        sb.append("origination");
        sb.append('=');
        sb.append(((this.origination == null)?"<null>":this.origination));
        sb.append(',');
        sb.append("paymentDigest");
        sb.append('=');
        sb.append(((this.paymentDigest == null)?"<null>":this.paymentDigest));
        sb.append(',');
        sb.append("destination");
        sb.append('=');
        sb.append(((this.destination == null)?"<null>":this.destination));
        sb.append(',');
        sb.append("taxes");
        sb.append('=');
        sb.append(((this.taxes == null)?"<null>":this.taxes));
        sb.append(',');
        sb.append("promotion");
        sb.append('=');
        sb.append(((this.promotion == null)?"<null>":this.promotion));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
