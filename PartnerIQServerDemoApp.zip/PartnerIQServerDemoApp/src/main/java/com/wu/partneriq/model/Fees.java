
package com.wu.partneriq.model;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.validation.Valid;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "charges",
    "delivery_charges",
    "other_charges"
})
@Generated("jsonschema2pojo")
public class Fees {

    @JsonProperty("charges")
    private Integer charges;
    @JsonProperty("delivery_charges")
    private Integer deliveryCharges;
    @JsonProperty("other_charges")
    private Integer otherCharges;
    @JsonIgnore
    @Valid
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("charges")
    public Integer getCharges() {
        return charges;
    }

    @JsonProperty("charges")
    public void setCharges(Integer charges) {
        this.charges = charges;
    }

    @JsonProperty("delivery_charges")
    public Integer getDeliveryCharges() {
        return deliveryCharges;
    }

    @JsonProperty("delivery_charges")
    public void setDeliveryCharges(Integer deliveryCharges) {
        this.deliveryCharges = deliveryCharges;
    }

    @JsonProperty("other_charges")
    public Integer getOtherCharges() {
        return otherCharges;
    }

    @JsonProperty("other_charges")
    public void setOtherCharges(Integer otherCharges) {
        this.otherCharges = otherCharges;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Fees.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("charges");
        sb.append('=');
        sb.append(((this.charges == null)?"<null>":this.charges));
        sb.append(',');
        sb.append("deliveryCharges");
        sb.append('=');
        sb.append(((this.deliveryCharges == null)?"<null>":this.deliveryCharges));
        sb.append(',');
        sb.append("otherCharges");
        sb.append('=');
        sb.append(((this.otherCharges == null)?"<null>":this.otherCharges));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
