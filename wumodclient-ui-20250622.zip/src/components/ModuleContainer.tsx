import { withRouter } from "../utils/withRouter";
import { Button, Card, Col, Container, FloatingLabel, Form, Row} from "react-bootstrap";
import NameModule from "./NameModule";
import { NameType } from "./NameModule";

type ModuleContainerProps =  {
    title: string;
}

const ModuleContainer: React.FC<ModuleContainerProps> = (props) => {
    return (
            <Container>
                <Row>
                    <Col sm={10}>
                        <NameModule title="Recipient" type={NameType.TypeM}></NameModule>
                    </Col>
                </Row>
            </Container >
        );
}

export default withRouter(ModuleContainer);