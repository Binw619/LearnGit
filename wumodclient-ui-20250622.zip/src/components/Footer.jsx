import React, {Component} from 'react';

class Footer extends Component {
    render() {
        return (
            <div>
                <footer className="footer">
                    <span className="text-white text-center">All Rights Reserved 2024 @Javabin</span>
                </footer>
            </div>
        );
    }
}

export default Footer;