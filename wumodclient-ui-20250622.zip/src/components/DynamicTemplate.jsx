import React, { Component } from 'react';
import { useState, useEffect } from 'react';
import { withRouter } from "../utils/withRouter";
import TemplateFields from './TemplateFields';
import { Button, Card, CardBody, Col, Container, FloatingLabel, Form, Row, Collapse } from "react-bootstrap";
import Dropdown from 'react-bootstrap/Dropdown';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import transferImg from "../img/transfer.png";

let dictionary = {};
let defaultValue = '';
let originationSelected = false;

const DynamicTemplate = (props) => {
    const sendAmountLabelPrefix = "Send amount";
    const receiveAmountLabelPrefix = "Receive amount";
    const [countryCode, setCountryCode] = useState('');
    const [receiveCurrencyCode, setReceiveCurrencyCode] = useState('');
    const [sendAmount, setSendAmount] = useState('5000.00');
    const [receiveAmount, setReceiveAmount] = useState('5000.00');
    const [sendAmountLabel, setSendAmountLabel] = useState(sendAmountLabelPrefix);
    const [receiveAmountLabel, setReceiveAmountLabel] = useState(receiveAmountLabelPrefix);
    const [jsonText, setJsonText] = useState('');
    const [templateFields, setTemplateFields] = useState(new Array());
    const [showSenderDetails, setShowSenderDetails] = useState(false);
    //const [ccList, setCcList] = useState(new Array());
    dictionary["id_issue_date"] = new Date();
    dictionary["id_expiration_date"] = new Date();
    dictionary["date_of_birth"] = new Date();

    let ccList = props.ccList;
    console.log("DynamicTemplate cclist", ccList);

    /*useEffect(() => {
        getCountryCurrencyList();
        console.log("ccList", ccList);
      }, []);*/

    const [issueDate, setIssueDate] = useState(new Date());
    const [expireDate, setExpireDate] = useState(new Date());

    function RenderDropdown(props) {
        const dropdown = props.dropdown;
        let content = [];
        let n = dropdown.length;
        for (let i = 0; i < n; i++) {
            const option = dropdown[i];
            if (option.defaultOption === true) {
                content.push(
                    <option key={option.text} value={option.value} selected>{option.text}</option>
                );
            } else {
                content.push(
                    <option key={option.text} value={option.value}>{option.text}</option>
                );
            }
        }
        return content;
    }

    function RenderTemplateFields() {
        let content = [];
        content.push(
            <Row>
                <Col>
                    <FloatingLabel
                        controlId="address"
                        label="Address"
                        className="mb-3"
                    >
                        <Form.Control type="input" placeholder=""
                            defaultValue="    "
                        />
                    </FloatingLabel>
                </Col>
                <Col>
                    <FloatingLabel
                        controlId="city"
                        label="City"
                        className="mb-3"
                    >
                        <Form.Control type="input" placeholder=""
                            defaultValue="    "
                        />
                    </FloatingLabel>
                </Col>
                <Col>
                    <FloatingLabel
                        controlId="contactPhone"
                        label="Contact phone"
                        className="mb-3"
                    >
                        <Form.Control type="input" placeholder=""
                            defaultValue="    "
                        />
                    </FloatingLabel>
                </Col>
            </Row>
        );

        let n = templateFields.length;
        for (let i = 0; i < n; i++) {
            const field = templateFields[i];
            console.log("my field.fieldName : ", field.fieldName);
            defaultValue = "     ";
            /*defaultValue = dictionary[field.fieldName];
            if (!defaultValue || defaultValue === '') {
                defaultValue = "enter " + field.fieldText;
            }*/
            //console.log("my defaultValue : ", defaultValue);
            //dictionary[field.fieldName] = "";

            if (field.fieldType === 'DROPDOWN') {
                if (field.fieldName === 'gender' ||
                    field.fieldName === 'id_type' ||
                    field.fieldName === 'id_country_of_issue' ||
                    field.fieldName === 'occupation' ||
                    field.fieldName === 'transaction_reason' ||
                    field.fieldName === 'country_of_birth' ||
                    field.fieldName === 'nationality' ||
                    field.fieldName === 'source_of_funds' ||
                    field.fieldName === 'relationship_to_receiver_sender') {
                    const dropdownOptions = field.dropdown;
                    const m = dropdownOptions.length;
                    content.push(
                        <Form.Group className="mb-2" controlId={field.fieldName} key={field.fieldName}>
                            <FloatingLabel
                                controlId={field.fieldName}
                                label={'[' + field.fieldText + ']'}
                                className="mb-3"
                            >
                                <select className="form-select form-select-sm" aria-label=".form-select-sm example">
                                    <RenderDropdown dropdown={dropdownOptions} />
                                </select>
                            </FloatingLabel>
                        </Form.Group>
                    );
                } else {
                    content.push(
                        <Form.Group className="mb-2" controlId={field.fieldName} key={field.fieldName}>
                            <FloatingLabel
                                controlId={field.fieldName}
                                label={'[' + field.fieldText + ']'}
                                className="mb-3"
                            >
                                <select className="form-select form-select-sm" aria-label=".form-select-sm example">
                                    <option key="1" value="1">One</option>
                                    <option key="2" value="2">Two</option>
                                    <option key="3" value="3">Three</option>
                                </select>
                            </FloatingLabel>
                        </Form.Group>
                    );
                }
            } else if (field.fieldType === 'DATE') {
                console.log("field.fieldType !!! ", field.fieldType);
                content.push(
                    <>
                        <Row>
                            <Col sm={3}>
                                <label style={{ marginLeft: "14px", marginBottom: "5px", fontSize: "14px", color: 'gray', display: 'flex', justifyContent: "start" }}>{'[' + field.fieldText + ']'}</label>
                            </Col></Row>
                        <Row>
                            <Col sm={7} style={{ marginLeft: "14px", fontSize: "14px", marginBottom: "15px", display: 'flex', justifyContent: "start", zIndex: 11 }}>
                                <DatePicker
                                    ariaLabelClose="aaa"
                                    selected={dictionary[field.fieldName]}
                                    //onSelect={handleDateSelect} //when day is clicked
                                    onChange={(date) => { dictionary[field.fieldName] = date; }} //only when value has changed
                                />
                            </Col>
                        </Row>
                    </>
                );
            } else if (field.fieldName != 'template_id' && field.fieldName != 'version') {
                content.push(
                    <Form.Group className="mb-2" controlId={field.fieldName} key={field.fieldName}>
                        <FloatingLabel
                            controlId={field.fieldName}
                            label={'[' + field.fieldText + ']'}
                            className="mb-3"
                        >
                            <Form.Control type="input" placeholder={field.fieldText} onChange={changeFieldValue}
                                defaultValue={defaultValue}
                            />
                        </FloatingLabel>
                    </Form.Group>
                );
            }
        }
        return content;
    }

    function JSONWindow() {
        const [open, setOpen] = useState(false);
        return (
            <>
                <Row>
                    <Col sm={3}>
                        <label
                            style={{ marginTop: '10px', fontWeight: "bold", fontSize: "18px", display: 'flex', justifyContent: "start", alignItems: "center" }}>
                            Send money overseas from </label>
                    </Col>
                    <Col sm={3}>
                        <Form style={{ marginTop: '10px' }}>
                            <Form.Group className="mb-2" controlId="countryCode">
                                <Form.Select aria-label="Select a country" size='sm' value={countryCode} onChange={changeCountryCode}>
                                    <option>Select a country</option>
                                    <option value="PH">Philippines</option>
                                    <option value="CN">China</option>
                                </Form.Select>
                            </Form.Group>
                        </Form>
                    </Col>
                    <Col>
                        <Button
                            variant="secondary"
                            size="sm"
                            className="d-flex justify-content-start"
                            style={{ marginTop: '10px' }}
                            onClick={() => setOpen(!open)}
                            aria-controls="json-message-window"
                            aria-expanded={open}
                        >
                            Show JSON
                        </Button>
                    </Col>
                </Row>
                <Row style={{ marginTop: '10px' }}>
                    <Col sm={3}>
                        <Form.Group className="mb-2" controlId="destination">
                            <FloatingLabel
                                controlId="destination"
                                label="Send to"
                                className="mb-3"
                            >
                                <Form.Select aria-label="Select a country" size='sm' onChange={changeDestination}>
                                    <RenderDropdown dropdown={ccList} />
                                </Form.Select>
                            </FloatingLabel>
                        </Form.Group>
                    </Col>
                    <Col sm={3}>
                        <Form.Group className="mb-2" controlId="sendamount">
                            <FloatingLabel
                                controlId="sendamount"
                                label={sendAmountLabel}
                                className="mb-3"
                            >
                                <Form.Control type="input" placeholder=""
                                    defaultValue={sendAmount}
                                />
                            </FloatingLabel>
                        </Form.Group>
                    </Col>
                    <Col sm={1}>
                        <img src={transferImg} style={{ width: "20px", height: "20px", marginTop: "20px" }}></img>
                    </Col>
                    <Col sm={3}>
                        <Form.Group className="mb-2" controlId="receiveamount">
                            <FloatingLabel
                                controlId="receiveamount"
                                label={receiveAmountLabel}
                                className="mb-3"
                            >
                                <Form.Control type="input" placeholder=""
                                    defaultValue={receiveAmount}
                                />
                            </FloatingLabel>
                        </Form.Group>
                    </Col>
                </Row>
                <Row>
                    <Col sm={10}>
                        <Collapse in={open}>
                            <div id="json-message-window">
                                <Form>
                                    <Form.Group className="mb-2" controlId="json_text">
                                        <FloatingLabel
                                            controlId="floatingInput"
                                            label="JSON"
                                            className="mb-3"
                                        >
                                            <Form.Control as="textarea" rows={5} style={{ height: 'unset' }} value={jsonText}
                                                readOnly={true} />
                                        </FloatingLabel>
                                    </Form.Group>
                                </Form>
                            </div>
                        </Collapse>
                    </Col>
                </Row>
            </>
        );
    }

    const handleDateSelect = (event) => {
    }

    const changeFieldValue = (event) => {
        //console.log("event.target id ", event.target.id);
        const fieldId = event.target.id;
        const value = event.target.value;
        dictionary[fieldId] = value;
    }

    const changeDestination = (event) => {
        const targetId = event.target.id;
        const cc = event.target.value;
        setReceiveCurrencyCode(cc);
        setReceiveAmountLabel(receiveAmountLabelPrefix + " - " + cc);
    }

    const changeCountryCode = (event) => {
        const countryCode = event.target.value;
        if (countryCode === 'PH') {
            let templateRequest = {
                templateId: 'UNI_01',
                version: 'PH_1.1',
                countryCode: 'PH',
                currencyCode: 'PHP'
            };
            dictionary["template_id"] = 'UNI_01';
            dictionary["version"] = 'PH_1.1';
            requestTemplate(templateRequest);
            setSendAmountLabel(sendAmountLabelPrefix + ' - PHP');

        } else if (countryCode === 'CN') {
            let templateRequest = {
                templateId: 'CHN_01',
                version: 'CHN_01',
                countryCode: 'CN',
                currencyCode: 'USD'
            };
            dictionary['template_id'] = 'CHN_01';
            dictionary['version'] = 'CHN_01';
            requestTemplate(templateRequest);
            setSendAmountLabel(sendAmountLabelPrefix + ' - USD');
        }
    };

    const requestTemplate = async (templateRequest) => {
        await fetch('http://localhost:8080/template', {
            method: 'POST',
            body: JSON.stringify(templateRequest),
            headers: {
                'Content-type': 'application/json; charset=UTF-8',
            },
        })
            .then((response) => response.json())
            .then((data) => {
                console.log("data.obj.templateFields", data.obj.templateFields);
                setTemplateFields(data.obj.templateFields);
                setCountryCode(data.obj.countryCode);
                setJsonText(JSON.stringify(data.obj, null, 2));
            })
            .catch((err) => {
                console.log(err.message);
            });
    };

    return (
        <Container>
            <JSONWindow />
            <Row>
                <Col sm={10}>
                    <Card style={{ width: '100%', marginTop: '10px' }}>
                        <Card.Body>
                            <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                                Sender
                            </Card.Title>
                            <Form>
                                <Row>
                                    <Col>
                                        <FloatingLabel
                                            controlId="firstName"
                                            label="First Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="middleName"
                                            label="Middle Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="lastName"
                                            label="Last Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col>
                                        <Button
                                            variant="secondary"
                                            size="sm"
                                            className="d-flex justify-content-start"
                                            style={{ marginBottom: '10px' }}
                                            onClick={() => setShowSenderDetails(!showSenderDetails)}
                                            aria-controls="show-sender-details-window"
                                            aria-expanded={showSenderDetails}
                                        >
                                            Add sender details
                                        </Button>
                                    </Col>
                                </Row>
                                <Collapse in={showSenderDetails}>
                                    <div id="show-sender-details-window">
                                        <RenderTemplateFields />
                                    </div>
                                </Collapse>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
                <Col sm={10}>
                    <Card style={{ width: '100%', marginTop: '10px' }}>
                        <Card.Body>
                            <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                                Receiver
                            </Card.Title>
                            <Form>
                                <Row>
                                    <Col>
                                        <FloatingLabel
                                            controlId="firstName"
                                            label="First Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="middleName"
                                            label="Middle Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="lastName"
                                            label="Last Name"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="    "
                                            />
                                        </FloatingLabel>
                                    </Col>
                                </Row>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
                <Col sm={10}>
                    <Card style={{ width: '100%', marginTop: '10px' }}>
                        <Card.Body>
                            <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                                How does your receiver want the money?
                            </Card.Title>
                            <Form>
                                <Row>
                                    <Col>
                                        <FloatingLabel
                                            controlId="cashPickup"
                                            label="Cash pickup"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="In minutes"
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="bankAccount"
                                            label="Bank account"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="Real time"
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="eWallet"
                                            label="eWallet"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue="In minutes"
                                            />
                                        </FloatingLabel>
                                    </Col>
                                </Row>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
                <Col sm={10}>
                    <Card style={{ width: '100%', marginTop: '10px' }}>
                        <Card.Body>
                            <Card.Title style={{ fontSize: "18px", color: 'black', display: 'flex', justifyContent: "start" }}>
                                How would you like to pay?
                            </Card.Title>
                            <Form>
                                <Row>
                                    <Col>
                                        <FloatingLabel
                                            controlId="payAtStore"
                                            label="Pay at convenient store"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue=""
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                        <FloatingLabel
                                            controlId="bankTransfer"
                                            label="Bank transfer"
                                            className="mb-3"
                                        >
                                            <Form.Control type="input" placeholder=""
                                                defaultValue=""
                                            />
                                        </FloatingLabel>
                                    </Col>
                                    <Col>
                                    </Col>
                                </Row>
                            </Form>
                        </Card.Body>
                    </Card>
                </Col>
                <Col sm={10}>
                    <Card style={{ width: '100%', marginTop: '10px' }}>
                        <Card.Body>
                            <Button
                                variant="success"
                                //size="sm"
                                className="d-flex justify-content-start"
                                style={{ marginTop: '10px' }}
                            >
                                Continue
                            </Button>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container >
    );

}

export default withRouter(DynamicTemplate);